import json

from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework.exceptions import ValidationError
from .serializers import CollegeBasicInfoCreateSerializer
import random
from django.utils import timezone
from datetime import timedelta
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status,permissions
from .models import LoginOTP
from django.contrib.auth.hashers import check_password

from .serializers import *
from django.contrib.auth import get_user_model

User = get_user_model()

from django.core.exceptions import ValidationError as DjangoValidationError
from rest_framework.exceptions import ValidationError as DRFValidationError
from django.db import IntegrityError
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status


def get_first_error_message(errors):
    if isinstance(errors, dict):
        for key, value in errors.items():
            if isinstance(value, list) and value:
                return str(value[0])
            elif isinstance(value, dict):
                nested_message = get_first_error_message(value)
                if nested_message:
                    return nested_message
            elif isinstance(value, str):
                return value
    elif isinstance(errors, list) and errors:
        return str(errors[0])
    return "Validation failed."


class CollegeBasicInfoCreateAPIView(APIView):
    permission_classes = []

    def post(self, request):
        print("request.data =>", request.data)

        serializer = CollegeBasicInfoCreateSerializer(data=request.data)

        if not serializer.is_valid():
            print("serializer.errors =>", serializer.errors)
            return Response({
                "status": False,
                "message": get_first_error_message(serializer.errors)
            }, status=status.HTTP_400_BAD_REQUEST)

        try:
            college = serializer.save()
            print("college saved =>", college.id)

            return Response({
                "status": True,
                "message": "Basic information saved successfully.",
                "data": {
                    "id": college.id,
                    "registration_number": college.registration_number,
                    "full_name": college.full_name,
                    "current_step": 1,
                    "next_step": "institution_details"
                }
            }, status=status.HTTP_201_CREATED)

        except (DRFValidationError, DjangoValidationError) as e:
            errors = getattr(e, "detail", None) or getattr(e, "message_dict", None) or str(e)
            print("save validation error =>", errors)

            return Response({
                "status": False,
                "message": get_first_error_message(errors)
            }, status=status.HTTP_400_BAD_REQUEST)

        except IntegrityError as e:
            print("IntegrityError =>", str(e))
            return Response({
                "status": False,
                "message": str(e)
            }, status=status.HTTP_400_BAD_REQUEST)

        except Exception as e:
            print("save error =>", str(e))
            return Response({
                "status": False,
                "message": str(e)
            }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

# class CollegeBasicInfoCreateAPIView(APIView):
#     permission_classes = []

#     def post(self, request):
#         print("request.data =>", request.data)

#         serializer = CollegeBasicInfoCreateSerializer(data=request.data)

#         if not serializer.is_valid():
#             print("serializer.errors =>", serializer.errors)
#             return Response({
#                 "status": False,
#                 "message": "Validation failed.",
#                 "errors": serializer.errors
#             }, status=status.HTTP_400_BAD_REQUEST)

#         try:
#             college = serializer.save()
#             print("college saved =>", college.id)

#             return Response({
#                 "status": True,
#                 "message": "Basic information saved successfully.",
#                 "data": {
#                     "id": college.id,
#                     "registration_number": college.registration_number,
#                     "full_name": college.full_name,
#                     "current_step": 1,
#                     "next_step": "institution_details"
#                 }
#             }, status=status.HTTP_201_CREATED)

#         except ValidationError as e:
#             print("save validation error =>", e.detail)
#             return Response({
#                 "status": False,
#                 "message": "Validation failed during save.",
#                 "errors": e.detail
#             }, status=status.HTTP_400_BAD_REQUEST)

#         except Exception as e:
#             print("save error =>", str(e))
#             return Response({
#                 "status": False,
#                 "message": "Something went wrong while saving data.",
#                 "error": str(e)
#             }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        
def send_otp_sms(mobile_no, otp):
    # Twilio / Fast2SMS / MSG91 integration yahan lagao
    # Example: message body -> f"Your OTP is {otp}"
    pass

# from .models import CollegeRegistration, CollegeContactPerson, LoginOTP


# import traceback

# class SendOTPView(APIView):
#     permission_classes = [permissions.AllowAny]

#     def post(self, request):
#         try:
#             serializer = SendOTPSerializer(data=request.data)
#             serializer.is_valid(raise_exception=True)

#             registration_number = serializer.validated_data["registration_number"].strip()
#             password = serializer.validated_data["password"]
#             mobile_no = serializer.validated_data["mobile_no"].strip()

#             college = CollegeRegistration.objects.filter(
#                 registration_number__iexact=registration_number
#             ).first()

#             if not college or not college.check_password(password):
#                 return Response(
#                     {"detail": "Invalid registration number or password."},
#                     status=status.HTTP_400_BAD_REQUEST
#                 )

#             contact = CollegeContactPerson.objects.filter(
#                 college=college,
#                 phone=mobile_no
#             ).first()

#             if not contact:
#                 return Response(
#                     {"detail": "Entered mobile number does not match our records."},
#                     status=status.HTTP_400_BAD_REQUEST
#                 )

#             if not contact:
#                 return Response(
#                     {"detail": "Phone number not found for this college."},
#                     status=status.HTTP_400_BAD_REQUEST
#                 )

#             phone = str(contact.phone).strip()
#             otp = str(random.randint(100000, 999999))

#             LoginOTP.objects.filter(
#                 college=college,
#                 mobile_no=mobile_no,
#                 is_used=False
#             ).update(is_used=True)

#             otp_obj = LoginOTP.objects.create(
#                 college=college,
#                 mobile_no=mobile_no,
#                 otp_code=otp,
#                 is_used=False,
#                 attempts=0,
#                 expires_at=timezone.now() + timedelta(minutes=5)
#             )
#             send_otp_sms(phone, otp)

#             masked_phone = f"{phone[:2]}******{phone[-2:]}" if len(phone) >= 4 else phone

#             return Response(
#                 {
#                     "detail": "OTP sent successfully.",
#                     "phone": masked_phone,
#                     "otp_id": otp_obj.id,
#                     'otp': otp  # Remove this line in production, it's only for testing
#                 },
#                 status=status.HTTP_200_OK
#             )

#         except Exception as e:
#             print("ERROR:", str(e))
#             print(traceback.format_exc())
#             return Response(
#                 {"detail": str(e)},
#                 status=status.HTTP_500_INTERNAL_SERVER_ERROR
#             )

import traceback
from datetime import timedelta
from django.utils import timezone
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import permissions, status
from .utils import send_login_otp_email

from .models import CollegeRegistration, CollegeContactPerson, LoginOTP
from .serializers import *
from .utils import send_otp_sms
from django.utils.crypto import get_random_string

def generate_login_otp():
    return get_random_string(6, allowed_chars="0123456789")


class SendOTPView(APIView):
    permission_classes = [permissions.AllowAny]

    def post(self, request):
        try:
            serializer = SendLoginOTPSerializer(data=request.data)
            serializer.is_valid(raise_exception=True)

            generated_registration_no = serializer.validated_data["generated_registration_no"].strip()
            email = serializer.validated_data["email"].strip().lower()

            college = CollegeRegistration.objects.filter(
                generated_registration_no__iexact=generated_registration_no
            ).first()

            if not college:
                return Response(
                    {"detail": "Invalid generated registration number."},
                    status=status.HTTP_400_BAD_REQUEST
                )

            contact = CollegeContactPerson.objects.filter(
                college=college,
                email__iexact=email
            ).first()

            if not contact:
                return Response(
                    {"detail": "Entered email does not match our records."},
                    status=status.HTTP_400_BAD_REQUEST
                )

            LoginOTP.objects.filter(
                college=college,
                login_type="email",
                target__iexact=email,
                is_used=False
            ).update(is_used=True)


            otp_code = generate_login_otp()

            otp_obj = LoginOTP.objects.create(
                college=college,
                login_type="email",
                target=email,
                otp_code=otp_code,
                is_used=False,
                attempts=0,
                expires_at=timezone.now() + timedelta(minutes=10)
            )

            send_login_otp_email(email, otp_code)

            local, domain = email.split("@", 1)
            if len(local) <= 2:
                masked_local = local[0] + "*" * (len(local) - 1)
            else:
                masked_local = local[:2] + "*" * (len(local) - 2)

            masked_email = f"{masked_local}@{domain}"

            return Response(
                {
                    "status": True,
                    "detail": "OTP sent successfully.",
                    "email": masked_email,
                    "otp_id": otp_obj.id,
                },
                status=status.HTTP_200_OK
            )

        except Exception as e:
            print("ERROR:", str(e))
            print(traceback.format_exc())
            return Response(
                {
                    "status": False,
                    "detail": str(e)
                },
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )
# class SendOTPView(APIView):
#     permission_classes = [permissions.AllowAny]

#     def post(self, request):
#         try:
#             serializer = SendOTPSerializer(data=request.data)
#             serializer.is_valid(raise_exception=True)

#             registration_number = serializer.validated_data["registration_number"].strip()
#             password = serializer.validated_data["password"]
#             mobile_no = serializer.validated_data["mobile_no"].strip()

#             college = CollegeRegistration.objects.filter(
#                 registration_number__iexact=registration_number
#             ).first()

#             if not college or not college.check_password(password):
#                 return Response(
#                     {"detail": "Invalid registration number or password."},
#                     status=status.HTTP_400_BAD_REQUEST
#                 )

#             contact = CollegeContactPerson.objects.filter(
#                 college=college,
#                 phone=mobile_no
#             ).first()

#             if not contact:
#                 return Response(
#                     {"detail": "Entered mobile number does not match our records."},
#                     status=status.HTTP_400_BAD_REQUEST
#                 )

#             phone = str(contact.phone).strip()

#             LoginOTP.objects.filter(
#                 college=college,
#                 mobile_no=mobile_no,
#                 is_used=False
#             ).update(is_used=True)

#             otp_obj = LoginOTP.objects.create(
#                 college=college,
#                 mobile_no=mobile_no,
#                 otp_code="TWILIO",
#                 is_used=False,
#                 attempts=0,
#                 expires_at=timezone.now() + timedelta(minutes=10)
#             )

#             send_otp_sms(phone)

#             masked_phone = f"{phone[:2]}******{phone[-2:]}" if len(phone) >= 4 else phone

#             return Response(
#                 {
#                     "detail": "OTP sent successfully.",
#                     "phone": masked_phone,
#                     "otp_id": otp_obj.id,
#                 },
#                 status=status.HTTP_200_OK
#             )

#         except Exception as e:
#             print("ERROR:", str(e))
#             print(traceback.format_exc())
#             return Response(
#                 {"detail": str(e)},
#                 status=status.HTTP_500_INTERNAL_SERVER_ERROR
#             )


# import traceback
# from rest_framework.views import APIView
# from rest_framework.response import Response
# from rest_framework import permissions, status

# from .models import LoginOTP, CollegeAuthToken
# from .serializers import VerifyOTPSerializer, InstitutionInformationSerializer
# from .authentication import CollegeTokenAuthentication


# class VerifyOTPView(APIView):
#     permission_classes = [permissions.AllowAny]

#     def post(self, request):
#         try:
#             serializer = VerifyOTPSerializer(data=request.data)
#             serializer.is_valid(raise_exception=True)

#             mobile_no = serializer.validated_data["mobile_no"].strip()
#             otp = serializer.validated_data["otp"].strip()

#             otp_obj = LoginOTP.objects.filter(
#                 mobile_no=mobile_no,
#                 otp_code=otp,
#                 is_used=False
#             ).order_by("-created_at").first()

#             if not otp_obj:
#                 return Response(
#                     {"detail": "Invalid OTP."},
#                     status=status.HTTP_400_BAD_REQUEST
#                 )

#             if otp_obj.is_expired():
#                 return Response(
#                     {"detail": "OTP expired."},
#                     status=status.HTTP_400_BAD_REQUEST
#                 )

#             otp_obj.is_used = True
#             otp_obj.save(update_fields=["is_used"])

#             college = otp_obj.college
#             token, created = CollegeAuthToken.objects.get_or_create(college=college)

#             return Response(
#                 {
#                     "detail": "OTP verified successfully.",
#                     "college_id": college.id,
#                     "registration_number": college.registration_number,
#                     "mobile_no": otp_obj.mobile_no,
#                     "token": token.key
#                 },
#                 status=status.HTTP_200_OK
#             )

#         except Exception as e:
#             print("ERROR:", str(e))
#             print(traceback.format_exc())
#             return Response(
#                 {"detail": str(e)},
#                 status=status.HTTP_500_INTERNAL_SERVER_ERROR
#             )

import traceback
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import permissions, status

from .models import LoginOTP, CollegeAuthToken
from .serializers import *
from .utils import verify_otp_sms



class VerifyOTPView(APIView):
    permission_classes = [permissions.AllowAny]

    def post(self, request):
        serializer = VerifyLoginOTPSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        generated_registration_no = serializer.validated_data["generated_registration_no"]
        email = serializer.validated_data["email"]
        otp = serializer.validated_data["otp"]

        college = CollegeRegistration.objects.filter(
            generated_registration_no__iexact=generated_registration_no
        ).first()

        if not college:
            return Response(
                {"detail": "Invalid generated registration number."},
                status=status.HTTP_400_BAD_REQUEST
            )

        contact = CollegeContactPerson.objects.filter(
            college=college,
            email__iexact=email
        ).first()

        if not contact:
            return Response(
                {"detail": "Entered email does not match our records."},
                status=status.HTTP_400_BAD_REQUEST
            )

        otp_obj = LoginOTP.objects.filter(
            college=college,
            login_type="email",
            target__iexact=email,
            is_used=False
        ).order_by("-created_at").first()

        if not otp_obj:
            return Response(
                {"detail": "No OTP request found."},
                status=status.HTTP_400_BAD_REQUEST
            )

        if timezone.now() > otp_obj.expires_at:
            return Response(
                {"detail": "OTP has expired."},
                status=status.HTTP_400_BAD_REQUEST
            )

        if otp_obj.otp_code != otp:
            otp_obj.attempts += 1
            otp_obj.save(update_fields=["attempts"])
            return Response(
                {"detail": "Invalid OTP."},
                status=status.HTTP_400_BAD_REQUEST
            )

        otp_obj.is_used = True
        otp_obj.save(update_fields=["is_used"])

        token, _ = CollegeAuthToken.objects.get_or_create(college=college)

        return Response(
            {
                "detail": "Login successful.",
                "token": token.key,
                "college_name": college.full_name,
                "generated_registration_no": college.generated_registration_no,
                "contact_type": contact.contact_type,
                "email": contact.email,
            },
            status=status.HTTP_200_OK
        )

from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import permissions, status

from .serializers import InstitutionInformationSerializer
from .authentication import CollegeTokenAuthentication
from .models import LoginOTP


class InstitutionInformationUpdateAPIView(APIView):
    authentication_classes = [CollegeTokenAuthentication]
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request):
        college = request.user

        serializer = InstitutionInformationSerializer(
            college,
            data=request.data,
            partial=True
        )

        if not serializer.is_valid():
            return Response(
                {
                    "status": False,
                    "message": "Validation failed.",
                    "errors": serializer.errors
                },
                status=status.HTTP_400_BAD_REQUEST
            )

        serializer.save()

        latest_login_otp = LoginOTP.objects.filter(
            college=college,
            is_used=True
        ).order_by("-created_at").first()

        coach = college.contacts.filter(contact_type="coach").first()
        sports_teacher = college.contacts.filter(contact_type="sports_teacher").first()
        management_person = college.contacts.filter(contact_type="management_person").first()

        filled_by_map = {
            "Coach": coach.name if coach else None,
            "Sports Teacher": sports_teacher.name if sports_teacher else None,
            "Management Person": management_person.name if management_person else None,
            "Admin": None
        }

        return Response(
            {
                "status": True,
                "message": "Institution information saved successfully.",
                "login_context": {
                "login_type": latest_login_otp.login_type if latest_login_otp else None,
                "login_target": latest_login_otp.target if latest_login_otp else None,                    "college_name": college.full_name,
                    "registration_number": college.registration_number,
                    "filled_by": college.filled_by,
                    "filled_by_name": filled_by_map.get(college.filled_by)
                },
                "contact_persons": {
                    "coach": {
                        "name": coach.name if coach else None,
                        "phone": coach.phone if coach else None,
                        "email": coach.email if coach else None
                    },
                    "sports_teacher": {
                        "name": sports_teacher.name if sports_teacher else None,
                        "phone": sports_teacher.phone if sports_teacher else None,
                        "email": sports_teacher.email if sports_teacher else None
                    },
                    "management_person": {
                        "name": management_person.name if management_person else None,
                        "phone": management_person.phone if management_person else None,
                        "email": management_person.email if management_person else None
                    }
                },
                "data": serializer.data,
                "next_step": "team_members_or_documents"
            },
            status=status.HTTP_200_OK
        )
    

from rest_framework.response import Response
from rest_framework import permissions, status
from .authentication import CollegeTokenAuthentication
from .models import CollegeTeamMember
from .serializers import CollegeTeamMemberSerializer
import re
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import permissions, status
from rest_framework.parsers import MultiPartParser, FormParser, JSONParser

from .authentication import CollegeTokenAuthentication
from .models import CollegeTeamMember
from .serializers import CollegeTeamMemberSerializer




class AddTeamMembersAPIView(APIView):
    authentication_classes = [CollegeTokenAuthentication]
    permission_classes = [permissions.IsAuthenticated]
    parser_classes = [MultiPartParser, FormParser, JSONParser]

    def post(self, request):
        college = request.user

        data = request.data or {}
        files = request.FILES or {}

        print("CONTENT_TYPE =>", request.content_type)
        print("DATA =>", request.data)
        print("FILES =>", request.FILES)

        members_map = {}
        pattern = re.compile(r"^members\[(\d+)\]\[(\w+)\]$")

        for key in data.keys():
            match = pattern.match(key)
            if match:
                index = int(match.group(1))
                field = match.group(2)
                members_map.setdefault(index, {})
                members_map[index][field] = data.get(key)

        for key in files.keys():
            match = pattern.match(key)
            if match:
                index = int(match.group(1))
                field = match.group(2)
                members_map.setdefault(index, {})
                members_map[index][field] = files.get(key)

        members_data = [members_map[i] for i in sorted(members_map.keys())]

        if not members_data:
            return Response(
                {
                    "status": False,
                    "message": "No members data found. Send multipart/form-data with keys like members[0][name], members[0][photo]."
                },
                status=status.HTTP_400_BAD_REQUEST
            )

        serializer = CollegeTeamMemberSerializer(data=members_data, many=True)
        if not serializer.is_valid():
            return Response(
                {
                    "status": False,
                    "message": "Validation failed.",
                    "errors": serializer.errors
                },
                status=status.HTTP_400_BAD_REQUEST
            )

        created_members = [
            CollegeTeamMember.objects.create(college=college, **item)
            for item in serializer.validated_data
        ]

        return Response(
            {
                "status": True,
                "message": "Team members added successfully.",
                "college_name": college.full_name,
                "registration_number": college.registration_number,
                "count": len(created_members),
                "data": CollegeTeamMemberSerializer(created_members, many=True).data,
                "next_step": "documents_upload"
            },
            status=status.HTTP_201_CREATED
        )

# class AddTeamMembersAPIView(APIView):
#     authentication_classes = [CollegeTokenAuthentication]
#     permission_classes = [permissions.IsAuthenticated]
#     parser_classes = [MultiPartParser, FormParser, JSONParser]

#     def post(self, request):
#         college = request.user

#         data = request.data or {}
#         files = request.FILES or {}
#         print("CONTENT_TYPE =>", request.content_type)
#         print("DATA =>", request.data)
#         print("FILES =>", request.FILES)
#         members_map = {}
#         pattern = re.compile(r"^members\[(\d+)\]\[(\w+)\]$")

#         for key in data.keys():
#             match = pattern.match(key)
#             if match:
#                 index = int(match.group(1))
#                 field = match.group(2)
#                 members_map.setdefault(index, {})
#                 members_map[index][field] = data.get(key)

#         for key in files.keys():
#             match = pattern.match(key)
#             if match:
#                 index = int(match.group(1))
#                 field = match.group(2)
#                 members_map.setdefault(index, {})
#                 members_map[index][field] = files.get(key)

#         members_data = [members_map[i] for i in sorted(members_map.keys())]

#         if not members_data:
#             return Response(
#                 {
#                     "status": False,
#                     "message": "No members data found. Send multipart/form-data with keys like members[0][name], members[0][photo]."
#                 },
#                 status=status.HTTP_400_BAD_REQUEST
#             )

#         serializer = CollegeTeamMemberSerializer(data=members_data, many=True)
#         if not serializer.is_valid():
#             return Response(
#                 {
#                     "status": False,
#                     "message": "Validation failed.",
#                     "errors": serializer.errors
#                 },
#                 status=status.HTTP_400_BAD_REQUEST
#             )

#         created_members = [
#             CollegeTeamMember.objects.create(college=college, **item)
#             for item in serializer.validated_data
#         ]

#         return Response(
#             {
#                 "status": True,
#                 "message": "Team members added successfully.",
#                 "college_name": college.full_name,
#                 "registration_number": college.registration_number,
#                 "count": len(created_members),
#                 "data": CollegeTeamMemberSerializer(created_members, many=True).data,
#                 "next_step": "documents_upload"
#             },
#             status=status.HTTP_201_CREATED
#         )
    


# class AddTeamMembersAPIView(APIView):
#     authentication_classes = [CollegeTokenAuthentication]
#     permission_classes = [permissions.IsAuthenticated]

#     def post(self, request):
#         college = request.user
#         members_data = request.data.get("members", [])

#         if not members_data or not isinstance(members_data, list):
#             return Response(
#                 {
#                     "status": False,
#                     "message": "members list is required."
#                 },
#                 status=status.HTTP_400_BAD_REQUEST
#             )

#         serializer = CollegeTeamMemberSerializer(data=members_data, many=True)
#         if not serializer.is_valid():
#             return Response(
#                 {
#                     "status": False,
#                     "message": "Validation failed.",
#                     "errors": serializer.errors
#                 },
#                 status=status.HTTP_400_BAD_REQUEST
#             )

#         created_members = []
#         for item in serializer.validated_data:
#             member = CollegeTeamMember.objects.create(college=college, **item)
#             created_members.append(member)

#         response_serializer = CollegeTeamMemberSerializer(created_members, many=True)

#         return Response(
#             {
#                 "status": True,
#                 "message": "Team members added successfully.",
#                 "college_name": college.full_name,
#                 "registration_number": college.registration_number,
#                 "count": len(created_members),
#                 "data": response_serializer.data,
#                 "next_step": "documents_upload"
#             },
#             status=status.HTTP_201_CREATED
#         )
    


# views.py
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import permissions, status
from rest_framework.parsers import MultiPartParser, FormParser

from .authentication import CollegeTokenAuthentication
from .models import CollegeDocument
from .serializers import CollegeDocumentSerializer


class CollegeDocumentUploadAPIView(APIView):
    authentication_classes = [CollegeTokenAuthentication]
    permission_classes = [permissions.IsAuthenticated]
    parser_classes = [MultiPartParser, FormParser]

    def post(self, request):
        college = request.user

        document_obj = CollegeDocument.objects.filter(college=college).first()

        if document_obj:
            serializer = CollegeDocumentSerializer(
                document_obj,
                data=request.data,
                partial=True
            )
        else:
            serializer = CollegeDocumentSerializer(data=request.data)

        if not serializer.is_valid():
            return Response(
                {
                    "status": False,
                    "message": "Validation failed.",
                    "errors": serializer.errors
                },
                status=status.HTTP_400_BAD_REQUEST
            )

        document = serializer.save(college=college)

        uploaded_count = 0
        if document.registration_certificate:
            uploaded_count += 1
        if document.pan_card:
            uploaded_count += 1
        if document.additional_document:
            uploaded_count += 1

        return Response(
            {
                "status": True,
                "message": "Documents uploaded successfully.",
                "college_name": college.full_name,
                "registration_number": college.registration_number,
                "uploaded_document_count": uploaded_count,
                "data": {
                    "registration_certificate": document.registration_certificate.url if document.registration_certificate else None,
                    "pan_card": document.pan_card.url if document.pan_card else None,
                    "additional_document": document.additional_document.url if document.additional_document else None,
                },
                "next_step": "completed"
            },
            status=status.HTTP_200_OK
        )
    




# ===================================================================================
# Sponsore Registrations
# =============================================================================================

from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import permissions, status
from rest_framework.parsers import MultiPartParser, FormParser,JSONParser

from .serializers import SponsorRegistrationSerializer

from .urls import *

class SponsorRegistrationAPIView(APIView):
    permission_classes = [permissions.AllowAny]
    parser_classes = [MultiPartParser, FormParser, JSONParser]

    def post(self, request):
        data = request.data.copy()

        if "preferred_engagement_zones" in data and isinstance(data.get("preferred_engagement_zones"), str):
            data.setlist(
                "preferred_engagement_zones",
                request.data.getlist("preferred_engagement_zones")
            )

        if "target_demographic" in data and isinstance(data.get("target_demographic"), str):
            data.setlist(
                "target_demographic",
                request.data.getlist("target_demographic")
            )

        serializer = SponsorRegistrationSerializer(data=data)

        if not serializer.is_valid():
            return Response(
                {
                    "status": False,
                    "message": "Validation failed.",
                    "errors": serializer.errors,
                },
                status=status.HTTP_400_BAD_REQUEST,
            )

        sponsor = serializer.save()

        # 🔹 yahan emails bhejo
        try:
            send_sponsor_admin_notification(sponsor)
            send_sponsor_thank_you_email(sponsor)
        except Exception as e:
            # Optional: log karo, response me error mat fail karo
            print("EMAIL ERROR (sponsor registration):", str(e))

        return Response(
            {
                "status": True,
                "message": "Sponsor registration submitted successfully.",
                "data": {
                    "id": sponsor.id,
                    "company_name": sponsor.company_name,
                    "industry_sector": sponsor.industry_sector,
                    "contact_person": sponsor.full_name,
                    "email": sponsor.email,
                    "phone_number": sponsor.phone_number,
                    "sponsor_tier": sponsor.sponsor_tier,
                    "preferred_engagement_zones": sponsor.preferred_engagement_zones,
                    "primary_goal": sponsor.primary_goal,
                    "target_demographic": sponsor.target_demographic,
                    "require_stall_booth": sponsor.require_stall_booth,
                    "estimated_budget_range": sponsor.estimated_budget_range,
                    "partnership_duration": sponsor.partnership_duration,
                    "company_logo": sponsor.company_logo.url if sponsor.company_logo else None,
                    "gst_details": sponsor.gst_details.url if sponsor.gst_details else None,
                },
            },
            status=status.HTTP_201_CREATED,
        )

# class SponsorRegistrationAPIView(APIView):
#     permission_classes = [permissions.AllowAny]
#     parser_classes = [MultiPartParser, FormParser, JSONParser]

#     def post(self, request):
#         data = request.data.copy()

#         if "preferred_engagement_zones" in data and isinstance(data.get("preferred_engagement_zones"), str):
#             data.setlist(
#                 "preferred_engagement_zones",
#                 request.data.getlist("preferred_engagement_zones")
#             )

#         if "target_demographic" in data and isinstance(data.get("target_demographic"), str):
#             data.setlist(
#                 "target_demographic",
#                 request.data.getlist("target_demographic")
#             )

#         serializer = SponsorRegistrationSerializer(data=data)

#         if not serializer.is_valid():
#             return Response(
#                 {
#                     "status": False,
#                     "message": "Validation failed.",
#                     "errors": serializer.errors
#                 },
#                 status=status.HTTP_400_BAD_REQUEST
#             )

#         sponsor = serializer.save()

#         return Response(
#             {
#                 "status": True,
#                 "message": "Sponsor registration submitted successfully.",
#                 "data": {
#                     "id": sponsor.id,
#                     "company_name": sponsor.company_name,
#                     "industry_sector": sponsor.industry_sector,
#                     "contact_person": sponsor.full_name,
#                     "email": sponsor.email,
#                     "phone_number": sponsor.phone_number,
#                     "sponsor_tier": sponsor.sponsor_tier,
#                     "preferred_engagement_zones": sponsor.preferred_engagement_zones,
#                     "primary_goal": sponsor.primary_goal,
#                     "target_demographic": sponsor.target_demographic,
#                     "require_stall_booth": sponsor.require_stall_booth,
#                     "estimated_budget_range": sponsor.estimated_budget_range,
#                     "partnership_duration": sponsor.partnership_duration,
#                     "company_logo": sponsor.company_logo.url if sponsor.company_logo else None,
#                     "gst_details": sponsor.gst_details.url if sponsor.gst_details else None,
#                 }
#             },
#             status=status.HTTP_201_CREATED
#         )

from datetime import timedelta
from django.utils import timezone
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status

from .models import CollegeContactPerson, CollegeContactOTP
from .serializers import (
    SendCollegeContactOTPSerializer,
    VerifyCollegeContactOTPSerializer,
)
from .utils import *


class SendCollegeContactOTPAPIView(APIView):
    authentication_classes = []
    permission_classes = []

    def post(self, request):
        serializer = SendCollegeContactOTPSerializer(data=request.data)
        if not serializer.is_valid():
            return Response(
                {
                    "status": False,
                    "message": "Validation failed.",
                    "errors": serializer.errors
                },
                status=status.HTTP_400_BAD_REQUEST
            )

        contact_type = str(serializer.validated_data["contact_type"]).strip()
        target = str(serializer.validated_data["target"]).strip()
        verify_type = str(serializer.validated_data["type"]).strip().lower()
        if verify_type == "sms":
            target = serializer.validated_data["target"]   # 10 digit phone

            CollegeContactOTP.objects.filter(
                otp_type="sms",
                target=target,
                is_used=False
            ).update(is_used=True)

            otp = CollegeContactOTP.generate_otp()

            CollegeContactOTP.objects.create(
                college=None,
                contact=None,
                otp_type="sms",
                target=target,
                otp=otp,
                expires_at=timezone.now() + timedelta(minutes=10)
            )

            result = send_sms_quick_fast2sms(target, otp)

            success = str(result.get("return", "")).lower() == "true" or result.get("return") is True

            if not success:
                return Response(
                    {
                        "status": False,
                        "message": "Failed to send SMS OTP.",
                        "provider_response": result
                    },
                    status=status.HTTP_400_BAD_REQUEST
                )

            return Response(
                {
                    "status": True,
                    "message": "OTP sent successfully on phone number.",
                    "target": target,
                    "type": "sms"
                },
                status=status.HTTP_200_OK
            )
        # if verify_type == "sms":
        #     target = serializer.validated_data["target"]
        #     e164_target = serializer.validated_data["e164_target"]

        #     CollegeContactOTP.objects.filter(
        #         otp_type="sms",
        #         target=e164_target,
        #         is_used=False
        #     ).update(is_used=True)

        #     verification = send_sms_otp(e164_target)

        #     CollegeContactOTP.objects.create(
        #         college=None,
        #         contact=None,
        #         otp_type="sms",
        #         target=e164_target,
        #         otp="TWILIO",
        #         expires_at=timezone.now() + timedelta(minutes=10)
        #     )

        #     return Response(
        #         {
        #             "status": True,
        #             "message": "OTP sent successfully on phone number.",
        #             "target": target,
        #             "type": "sms",
        #             "twilio_status": verification.status
        #         },
        #         status=status.HTTP_200_OK
        #     )

        if verify_type == "email":
            target = target.lower()

            CollegeContactOTP.objects.filter(
                target__iexact=target,
                otp_type="email",
                is_used=False
            ).update(is_used=True)

            otp = CollegeContactOTP.generate_otp()

            CollegeContactOTP.objects.create(
                college=None,   # agar college bhi pre-registration me nahi hai to nullable karna padega
                contact=None,
                otp_type="email",
                target=target,
                otp=otp,
                expires_at=timezone.now() + timedelta(minutes=10)
            )

            send_email_otp(target, otp)

            return Response(
                {
                    "status": True,
                    "message": "OTP sent successfully on email.",
                    "target": target,
                    "type": "email"
                },
                status=status.HTTP_200_OK
            )
class VerifyCollegeContactOTPAPIView(APIView):
    authentication_classes = []
    permission_classes = []

    def post(self, request):
        serializer = VerifyCollegeContactOTPSerializer(data=request.data)
        if not serializer.is_valid():
            return Response(
                {
                    "status": False,
                    "message": "Validation failed.",
                    "errors": serializer.errors
                },
                status=status.HTTP_400_BAD_REQUEST
            )

        contact_type = serializer.validated_data["contact_type"]
        target = serializer.validated_data["target"]
        verify_type = serializer.validated_data["type"]
        otp = serializer.validated_data["otp"]
        if verify_type == "sms":
            target = serializer.validated_data["target"]
            otp = serializer.validated_data["otp"]
        
            otp_record = CollegeContactOTP.objects.filter(
                otp_type="sms",
                target=target,
                is_used=False
            ).order_by("-created_at").first()
        
            if not otp_record:
                return Response(
                    {
                        "status": False,
                        "message": "No OTP request found."
                    },
                    status=status.HTTP_404_NOT_FOUND
                )
        
            if otp_record.is_expired():
                return Response(
                    {
                        "status": False,
                        "message": "OTP has expired."
                    },
                    status=status.HTTP_400_BAD_REQUEST
                )
        
            if otp_record.otp != otp:
                return Response(
                    {
                        "status": False,
                        "message": "Invalid OTP."
                    },
                    status=status.HTTP_400_BAD_REQUEST
                )
        
            otp_record.is_used = True
            otp_record.verified_at = timezone.now()
            otp_record.save(update_fields=["is_used", "verified_at"])
        
            return Response(
                {
                    "status": True,
                    "message": "Phone number verified successfully.",
                    "target": target,
                    "type": "sms",
                    "phone_verified": True
                },
                status=status.HTTP_200_OK
            )
                # if verify_type == "sms":
                #     target = serializer.validated_data["target"]
        #     e164_target = serializer.validated_data["e164_target"]
        #     otp = serializer.validated_data["otp"]

        #     verification_check = verify_sms_otp(e164_target, otp)

        #     if verification_check.status != "approved":
        #         return Response(
        #             {
        #                 "status": False,
        #                 "message": "Invalid or expired OTP."
        #             },
        #             status=status.HTTP_400_BAD_REQUEST
        #         )

        #     otp_record = CollegeContactOTP.objects.filter(
        #         otp_type="sms",
        #         target=e164_target,
        #         is_used=False
        #     ).order_by("-created_at").first()

        #     if otp_record:
        #         otp_record.is_used = True
        #         otp_record.verified_at = timezone.now()
        #         otp_record.save(update_fields=["is_used", "verified_at"])

        #     return Response(
        #         {
        #             "status": True,
        #             "message": "Phone number verified successfully.",
        #             "target": target,
        #             "type": "sms",
        #             "phone_verified": True
        #         },
        #         status=status.HTTP_200_OK
        #     )

        if verify_type == "email":
            otp_record = CollegeContactOTP.objects.filter(
                otp_type="email",
                target__iexact=target,
                is_used=False
            ).order_by("-created_at").first()

            if not otp_record:
                return Response(
                    {
                        "status": False,
                        "message": "No OTP request found."
                    },
                    status=status.HTTP_404_NOT_FOUND
                )

            if otp_record.is_expired():
                return Response(
                    {
                        "status": False,
                        "message": "OTP has expired."
                    },
                    status=status.HTTP_400_BAD_REQUEST
                )

            if otp_record.otp != otp:
                return Response(
                    {
                        "status": False,
                        "message": "Invalid OTP."
                    },
                    status=status.HTTP_400_BAD_REQUEST
                )

            otp_record.is_used = True
            otp_record.verified_at = timezone.now()
            otp_record.save(update_fields=["is_used", "verified_at"])

            return Response(
                {
                    "status": True,
                    "message": "Email verified successfully.",
                    "target": target,
                    "type": "email",
                    "email_verified": True
                },
                status=status.HTTP_200_OK
            )



from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework.permissions import AllowAny

from .models import CollegeRegistration


class CollegeMasterDataAPIView(APIView):
    permission_classes = [AllowAny]

    def get_choices_list(self, model, field_name):
        field = model._meta.get_field(field_name)
        return [
            {"value": value, "label": label}
            for value, label in field.choices
        ]

    def get(self, request):
        return Response({
            "status": True,
            "message": "Master data fetched successfully.",
            "data": {
                "countries": self.get_choices_list(CollegeRegistration, "country"),
                "states": self.get_choices_list(CollegeRegistration, "state"),
            }
        }, status=status.HTTP_200_OK)

from datetime import timedelta

from django.conf import settings
from django.core.mail import send_mail
from django.utils import timezone

from rest_framework import status
from rest_framework.parsers import MultiPartParser, FormParser, JSONParser
from rest_framework.response import Response
from rest_framework.views import APIView

from .models import *
from .serializers import (
    VendorRegistrationSerializer,
    SendVendorContactOTPSerializer,
    VerifyVendorContactOTPSerializer,
)
from .utils import *


class VendorRegistrationCreateAPIView(APIView):
    parser_classes = [MultiPartParser, FormParser]
    authentication_classes = []
    permission_classes = []

    def post(self, request, *args, **kwargs):
        data = request.data.copy()

        file_fields = [
            "pan_card_copy",
            "gst_registration_certificate",
            "cancelled_cheque_or_passbook",
            "company_profile_or_pitch_deck",
            "signature_and_company_seal",
        ]

        for field in file_fields:
            uploaded_file = request.FILES.get(field)
            if uploaded_file:
                data[field] = uploaded_file

        serializer = VendorRegistrationSerializer(data=data)
        if serializer.is_valid():
            vendor = serializer.save()
            return Response(
                {
                    "status": True,
                    "message": "Vendor registration submitted successfully.",
                    "data": VendorRegistrationSerializer(vendor).data,
                },
                status=status.HTTP_201_CREATED,
            )

        return Response(
            {
                "status": False,
                "message": "Validation failed.",
                "errors": serializer.errors,
            },
            status=status.HTTP_400_BAD_REQUEST,
        )


class SendVendorContactOTPAPIView(APIView):
    authentication_classes = []
    permission_classes = []
    parser_classes = [JSONParser]

    def post(self, request):
        serializer = SendVendorContactOTPSerializer(data=request.data)

        if not serializer.is_valid():
            return Response(
                {
                    "status": False,
                    "message": "Validation failed.",
                    "errors": serializer.errors,
                },
                status=status.HTTP_400_BAD_REQUEST,
            )

        contact_type = serializer.validated_data["contact_type"]
        target = serializer.validated_data["target"]
        verify_type = serializer.validated_data["type"]

        if verify_type == "email":
            VendorContactOTP.objects.filter(
                contact_type=contact_type,
                otp_type="email",
                target__iexact=target,
                is_used=False
            ).update(is_used=True)

            otp = VendorContactOTP.generate_otp()

            VendorContactOTP.objects.create(
                contact_type=contact_type,
                otp_type="email",
                target=target.lower(),
                otp=otp,
                expires_at=timezone.now() + timedelta(minutes=10),
                is_verified=False,
                is_used=False,
            )

            send_email_otp(target.lower(), otp)

            return Response(
                {
                    "status": True,
                    "message": "OTP sent successfully on email.",
                    "target": target.lower(),
                    "type": "email",
                    "contact_type": contact_type,
                },
                status=status.HTTP_200_OK,
            )

        if verify_type == "sms":
            VendorContactOTP.objects.filter(
                contact_type=contact_type,
                otp_type="sms",
                target=target,
                is_used=False
            ).update(is_used=True)

            otp = VendorContactOTP.generate_otp()

            VendorContactOTP.objects.create(
                contact_type=contact_type,
                otp_type="sms",
                target=target,
                otp=otp,
                expires_at=timezone.now() + timedelta(minutes=10),
                is_verified=False,
                is_used=False,
            )

            sms_result = send_sms_quick_fast2sms(target, otp)
            sms_success = (
                str(sms_result.get("return", "")).lower() == "true"
                or sms_result.get("return") is True
            )

            if not sms_success:
                return Response(
                    {
                        "status": False,
                        "message": "Failed to send SMS OTP.",
                        "provider_response": sms_result,
                    },
                    status=status.HTTP_400_BAD_REQUEST,
                )

            return Response(
                {
                    "status": True,
                    "message": "OTP sent successfully on mobile number.",
                    "target": target,
                    "type": "sms",
                    "contact_type": contact_type,
                },
                status=status.HTTP_200_OK,
            )

        return Response(
            {
                "status": False,
                "message": "Invalid verification type.",
            },
            status=status.HTTP_400_BAD_REQUEST,
        )


class VerifyVendorContactOTPAPIView(APIView):
    authentication_classes = []
    permission_classes = []
    parser_classes = [JSONParser]

    def post(self, request):
        serializer = VerifyVendorContactOTPSerializer(data=request.data)

        if not serializer.is_valid():
            return Response(
                {
                    "status": False,
                    "message": "Validation failed.",
                    "errors": serializer.errors,
                },
                status=status.HTTP_400_BAD_REQUEST,
            )

        contact_type = serializer.validated_data["contact_type"]
        target = serializer.validated_data["target"]
        verify_type = serializer.validated_data["type"]
        otp = serializer.validated_data["otp"]

        if verify_type == "email":
            otp_record = VendorContactOTP.objects.filter(
                contact_type=contact_type,
                otp_type="email",
                target__iexact=target,
                is_used=False
            ).order_by("-created_at").first()

            if not otp_record:
                return Response(
                    {
                        "status": False,
                        "message": "No OTP request found."
                    },
                    status=status.HTTP_404_NOT_FOUND,
                )

            if otp_record.is_expired():
                return Response(
                    {
                        "status": False,
                        "message": "OTP has expired."
                    },
                    status=status.HTTP_400_BAD_REQUEST,
                )

            if otp_record.otp != otp:
                return Response(
                    {
                        "status": False,
                        "message": "Invalid OTP."
                    },
                    status=status.HTTP_400_BAD_REQUEST,
                )

            otp_record.is_used = True
            otp_record.is_verified = True
            otp_record.verified_at = timezone.now()
            otp_record.save(update_fields=["is_used", "is_verified", "verified_at"])

            return Response(
                {
                    "status": True,
                    "message": "Email verified successfully.",
                    "target": target.lower(),
                    "type": "email",
                    "contact_type": contact_type,
                    "email_verified": True,
                },
                status=status.HTTP_200_OK,
            )

        if verify_type == "sms":
            otp_record = VendorContactOTP.objects.filter(
                contact_type=contact_type,
                otp_type="sms",
                target=target,
                is_used=False
            ).order_by("-created_at").first()

            if not otp_record:
                return Response(
                    {
                        "status": False,
                        "message": "No OTP request found."
                    },
                    status=status.HTTP_404_NOT_FOUND,
                )

            if otp_record.is_expired():
                return Response(
                    {
                        "status": False,
                        "message": "OTP has expired."
                    },
                    status=status.HTTP_400_BAD_REQUEST,
                )

            if otp_record.otp != otp:
                return Response(
                    {
                        "status": False,
                        "message": "Invalid OTP."
                    },
                    status=status.HTTP_400_BAD_REQUEST,
                )

            otp_record.is_used = True
            otp_record.is_verified = True
            otp_record.verified_at = timezone.now()
            otp_record.save(update_fields=["is_used", "is_verified", "verified_at"])

            return Response(
                {
                    "status": True,
                    "message": "Mobile number verified successfully.",
                    "target": target,
                    "type": "sms",
                    "contact_type": contact_type,
                    "phone_verified": True,
                },
                status=status.HTTP_200_OK,
            )

        return Response(
            {
                "status": False,
                "message": "Invalid verification type.",
            },
            status=status.HTTP_400_BAD_REQUEST,
        )

class VendorRegistrationListAPIView(APIView):
    authentication_classes = []
    permission_classes = []

    def get(self, request):
        queryset = VendorRegistration.objects.all().order_by("-id")
        serializer = VendorRegistrationSerializer(queryset, many=True)

        return Response(
            {
                "status": True,
                "message": "Vendor registrations fetched successfully.",
                "count": queryset.count(),
                "data": serializer.data,
            },
            status=status.HTTP_200_OK
        )


class VendorRegistrationDetailAPIView(APIView):
    authentication_classes = []
    permission_classes = []

    def get(self, request, pk):
        vendor = VendorRegistration.objects.filter(pk=pk).first()

        if not vendor:
            return Response(
                {
                    "status": False,
                    "message": "Vendor registration not found.",
                },
                status=status.HTTP_404_NOT_FOUND
            )

        serializer = VendorRegistrationSerializer(vendor)

        return Response(
            {
                "status": True,
                "message": "Vendor registration fetched successfully.",
                "data": serializer.data,
            },
            status=status.HTTP_200_OK
        )





from .scoring_services import ScoringEngineService
from django.db.models import Sum, Count, Q


#=============================================
# MATCH SETUP & SCORING VIEWS
#=============================================

class MatchSetupAPIView(APIView):
    permission_classes=[permissions.AllowAny]

    def post(self,request):
        serializer=MatchSetupSerializer(data=request.data)
        if not serializer.is_valid():
            return Response({"status":False,"error":serializer.errors},status.HTTP_400_BAD_REQUEST)

        match = serializer.save()
        return Response({
            "status": True,
            "message": "Match created with playing squads successfully.",
            "match_id":match.id
        },status=status.HTTP_201_CREATED)
    
class RecordTossAPI(APIView):
    permission_classes=[permissions.AllowAny]

    def post(self,request,match_id):
        match=Match.objects.filter(id=match_id).first()
        if not match:
            return Response({"status":False, "message":"Match not found"}, status=status.HTTP_404_NOT_FOUND)

        serializer=TossRecordSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        match.toss_winner=serializer.validated_data['toss_winner']
        match.toss_decision=serializer.validated_data['toss_decision']
        match.status='upcoming '
        match.save()

        return Response({
            "status":True,
            "message":"Toss recorded successfully.",
            "match_id":match.id,
            "toss_winner":match.toss_winner.team_name,
            "toss_decision":match.toss_decision

        },status=status.HTTP_200_OK)

class StartInningsAPIView(APIView):
    permission_classes=[permissions.AllowAny]

    def post(self,request,match_id):
        match=Match.objects.filter(id=match_id).first()
        if not match:
            return Response({"status":False,"message":"Match not found"},status=status.HTTP_404_NOT_FOUND)

        serializer=StartInningsSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        innings_num=serializer.validated_data['innings_number']

        innings,_ = Innings.objects.get_or_create(
            match=match,
            innings_number=innings_num,
            defaults={
                'batting_team':serializer.validated_data['batting_team'],
                'bowling_team':serializer.validated_data['bowling_team']
            }
        )
        match.status='live'
        match.save(update_fields=["status"])

        return Response({
            "status":True,
            "message": f"Innings {innings_num} started successfully.",
            "innings_id":innings.id,
            "batting_team":innings.batting_team.team_name,
            "bowling_team":innings.bowling_team.team_name,
            "striker":serializer.validated_data['striker'].name,
            "non_striker":serializer.validated_data['non_striker'].name,
            "bowler":serializer.validated_data['bowler'].name
        },status=status.HTTP_200_OK)


class RecordBallAPIView(APIView):
    permission_classes=[permissions.AllowAny]

    def post(self, request,innings_id):
        innings=Innings.objects.filter(id=innings_id).first()
        if not innings:
            return Response({"status":False,"message":"Innings not found."},status=status.HTTP_404_NOT_FOUND)

        if innings.is_completed:
            return Response({"status":False,"message":"This innings is already completed."},status=status.HTTP_400_BAD_REQUEST)

        serializer=RecordBallSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        result=ScoringEngineService.process_delivery(innings,serializer.validated_data)

        return Response({
            "status":True,
            "message":"Delivery recorded Successfully.",
            "data":result
        },status=status.HTTP_200_OK)


#--------------------------------------------------------------------------
# Fan & Public live score api views
#----------------------------------------------------------------------------


class LiveMatchScorecardAPIView(APIView):
    permission_classes = [permissions.AllowAny]

    def get(self, request, match_id):
        match = Match.objects.filter(id=match_id).first()
        if not match:
            return Response({"status": False, "message": "Match not found."}, status=status.HTTP_404_NOT_FOUND)

        active_innings = match.innings.filter(is_completed=False).first() or match.innings.last()
        
        recent_balls = []
        if active_innings:
            recent_balls = list(active_innings.balls.order_by('-id')[:12].values(
                'over_number', 
                'ball_number', 
                'striker__name',   # <-- Striker Player Name
                'bowler__name',    # <-- Bowler Player Name
                'runs_scored', 
                'extra_type', 
                'is_wicket'
            ))

        return Response({
            "status": True,
            "match": {
                "id": match.id,
                "team_a": match.team_a.team_name,
                "team_b": match.team_b.team_name,
                "status": match.status,
                "result": match.result_description,
                "venue": str(match.venue) if match.venue else None,
            },
            "active_innings": {
                "innings_number": active_innings.innings_number if active_innings else None,
                "batting_team": active_innings.batting_team.team_name if active_innings else None,
                "total_runs": active_innings.total_runs if active_innings else 0,
                "total_wickets": active_innings.total_wickets if active_innings else 0,
                "total_overs": str(active_innings.total_overs) if active_innings else "0.0",
            } if active_innings else None,
            "recent_balls": recent_balls
        }, status=status.HTTP_200_OK)


class TournamentLeaderboardAPIView(APIView):
    permission_classes = [permissions.AllowAny]

    def get(self, request, tournament_id):
        # 1. Orange Cap: Top 5 Run Scorers
        top_batsmen = BallByBall.objects.filter(
            innings__match__tournament_id=tournament_id
        ).values(
            'striker__id', 
            'striker__name', 
            'striker__college__team_name'  # <-- college relationship ke through team_name
        ).annotate(
            total_runs=Sum('runs_scored'),
            balls_faced=Count('id', filter=Q(extra_type__in=['none', 'bye', 'leg_bye']))
        ).order_by('-total_runs')[:5]

        # 2. Purple Cap: Top 5 Wicket Takers
        top_bowlers = BallByBall.objects.filter(
            innings__match__tournament_id=tournament_id,
            is_wicket=True
        ).exclude(wicket_type__in=['run_out', 'retired_hurt', 'retired_out']).values(
            'bowler__id', 
            'bowler__name', 
            'bowler__college__team_name'  # <-- college relationship ke through team_name
        ).annotate(
            total_wickets=Count('id')
        ).order_by('-total_wickets')[:5]

        # 3. Standings / Points Table
        standings = PointsTable.objects.filter(tournament_id=tournament_id).order_by('-points', '-net_run_rate')

        # Clean JSON format for frontend
        orange_cap_data = [
            {
                "player_id": b["striker__id"],
                "player_name": b["striker__name"],
                "team_name": b["striker__college__team_name"],
                "total_runs": b["total_runs"] or 0,
                "balls_faced": b["balls_faced"] or 0
            }
            for b in top_batsmen
        ]

        purple_cap_data = [
            {
                "player_id": w["bowler__id"],
                "player_name": w["bowler__name"],
                "team_name": w["bowler__college__team_name"],
                "total_wickets": w["total_wickets"] or 0
            }
            for w in top_bowlers
        ]

        return Response({
            "status": True,
            "orange_cap": orange_cap_data,
            "purple_cap": purple_cap_data,
            "points_table": PointsTableSerializer(standings, many=True).data
        }, status=status.HTTP_200_OK)


# class HomepageMasterAPIView(APIView):
#     """
#     SOW Module 2 Compliant Master Homepage Data Feed.
#     Uses exact models: CollegeTeamMember, LiveStreamConfig, HomepageBanner, etc.
#     """
#     permission_classes = [permissions.AllowAny]

#     def get(self, request):
#         now = timezone.now()
#         active_tournament = Tournament.objects.filter(is_active=True).first() or Tournament.objects.last()

#         # A. Hero Banners
#         banners = [
#             {
#                 "id": b.id,
#                 "title": b.title,
#                 "subtitle": b.subtitle,
#                 "season_tag": b.season_tag,
#                 "banner_image": request.build_absolute_uri(b.banner_image.url) if b.banner_image else None,
#                 "cta_title": b.cta_title,
#                 "cta_url": b.cta_url
#             }
#             for b in HomepageBanner.objects.filter(is_active=True).order_by('-created_at')
#         ]

#         # B & C & D. Live Matches with YouTube Stream & Quick Info Panel
#         live_matches_data = []
#         live_matches = Match.objects.filter(status='live').select_related('team_a', 'team_b', 'venue', 'tournament')
        
#         for match in live_matches:
#             active_inn = match.innings.filter(is_completed=False).first() or match.innings.last()
#             last_ball = active_inn.balls.last() if active_inn else None
            
#             # YouTube Stream from LiveStreamConfig model
#             stream_config = getattr(match, 'live_stream', None)
#             youtube_url = stream_config.youtube_stream_url if (stream_config and stream_config.is_live) else None

#             # Required runs and balls calculation
#             req_runs = None
#             req_balls = None
#             if active_inn and getattr(active_inn, 'target_runs', None):
#                 req_runs = max(0, active_inn.target_runs - active_inn.total_runs)
#                 current_balls = int(active_inn.total_overs) * 6 + int(round((active_inn.total_overs % 1) * 10))
#                 req_balls = max(0, (match.total_overs * 6) - current_balls)

#             live_matches_data.append({
#                 "match_id": match.id,
#                 "tournament": match.tournament.name if match.tournament else None,
#                 "venue": f"{match.venue.name}, {match.venue.city}" if match.venue else None,
#                 "format": match.format,
#                 "total_overs": match.total_overs,
#                 "toss_info": f"{match.toss_winner.team_name} elected to {match.toss_decision}" if match.toss_winner else "Toss pending",
#                 "team_a": {
#                     "id": match.team_a.id,
#                     "name": match.team_a.team_name,
#                     "college": match.team_a.full_name
#                 },
#                 "team_b": {
#                     "id": match.team_b.id,
#                     "name": match.team_b.team_name,
#                     "college": match.team_b.full_name
#                 },
#                 "youtube_stream_url": youtube_url,
#                 "current_score": {
#                     "innings_number": active_inn.innings_number if active_inn else 1,
#                     "batting_team": active_inn.batting_team.team_name if active_inn else None,
#                     "runs": active_inn.total_runs if active_inn else 0,
#                     "wickets": active_inn.total_wickets if active_inn else 0,
#                     "overs": str(active_inn.total_overs) if active_inn else "0.0",
#                     "required_runs": req_runs,
#                     "required_balls": req_balls
#                 },
#                 "quick_panel": {
#                     "striker": {
#                         "id": last_ball.striker.id,
#                         "name": last_ball.striker.name,
#                         "code": last_ball.striker.member_code
#                     } if (last_ball and last_ball.striker) else None,
#                     "non_striker": {
#                         "id": last_ball.non_striker.id,
#                         "name": last_ball.non_striker.name,
#                         "code": last_ball.non_striker.member_code
#                     } if (last_ball and last_ball.non_striker) else None,
#                     "bowler": {
#                         "id": last_ball.bowler.id,
#                         "name": last_ball.bowler.name,
#                         "code": last_ball.bowler.member_code
#                     } if (last_ball and last_ball.bowler) else None
#                 }
#             })

#         # E. Upcoming Matches
#         upcoming = [
#             {
#                 "match_id": m.id,
#                 "teams": f"{m.team_a.team_name} vs {m.team_b.team_name}",
#                 "date_time": m.match_datetime.strftime("%Y-%m-%d %H:%M"),
#                 "venue": f"{m.venue.name}, {m.venue.city}" if m.venue else "TBD",
#                 "format": m.format
#             }
#             for m in Match.objects.filter(status='upcoming', match_datetime__gte=now).order_by('match_datetime')[:5]
#         ]

#         # F. Recent Results
#         recent_results = [
#             {
#                 "match_id": m.id,
#                 "teams": f"{m.team_a.team_name} vs {m.team_b.team_name}",
#                 "winner": m.winner.team_name if m.winner else "No Result / Tie",
#                 "result_description": m.result_description or "Match Completed",
#                 "player_of_the_match": m.player_of_match.name if m.player_of_match else None
#             }
#             for m in Match.objects.filter(status='completed').order_by('-match_datetime')[:5]
#         ]

#         # G. Tournament Snapshot Cards
#         total_matches = Match.objects.filter(tournament=active_tournament).count() if active_tournament else 0
#         completed_matches = Match.objects.filter(tournament=active_tournament, status='completed').count() if active_tournament else 0
#         live_count = Match.objects.filter(tournament=active_tournament, status='live').count() if active_tournament else 0

#         snapshot = {
#             "total_teams": CollegeRegistration.objects.filter(status='approved').count(),
#             "total_matches": total_matches,
#             "completed_matches": completed_matches,
#             "live_matches": live_count,
#             "upcoming_matches": max(0, total_matches - (completed_matches + live_count)),
#             "total_players": CollegeTeamMember.objects.count()
#         }

#         # H. Featured Players (Aggregated from BallByBall deliveries)
#         top_batsmen_qs = (
#             CollegeTeamMember.objects.annotate(total_runs=Sum('striker_balls__runs_scored'))
#             .filter(total_runs__isnull=False)
#             .order_by('-total_runs')[:5]
#         )
#         orange_cap = [
#             {
#                 "player_id": p.id,
#                 "name": p.name,
#                 "member_code": p.member_code,
#                 "team": p.college.team_name,
#                 "runs": p.total_runs
#             }
#             for p in top_batsmen_qs
#         ]

#         top_bowlers_qs = (
#             CollegeTeamMember.objects.annotate(
#                 total_wickets=Count('bowled_balls', filter=Q(bowled_balls__is_wicket=True) & ~Q(bowled_balls__wicket_type='run_out'))
#             )
#             .filter(total_wickets__gt=0)
#             .order_by('-total_wickets')[:5]
#         )
#         purple_cap = [
#             {
#                 "player_id": p.id,
#                 "name": p.name,
#                 "member_code": p.member_code,
#                 "team": p.college.team_name,
#                 "wickets": p.total_wickets
#             }
#             for p in top_bowlers_qs
#         ]

#         most_sixes_qs = (
#             CollegeTeamMember.objects.annotate(
#                 total_sixes=Count('striker_balls', filter=Q(striker_balls__is_six=True))
#             )
#             .filter(total_sixes__gt=0)
#             .order_by('-total_sixes')[:5]
#         )
#         most_sixes = [
#             {"player_id": p.id, "name": p.name, "team": p.college.team_name, "sixes": p.total_sixes}
#             for p in most_sixes_qs
#         ]

#         most_fours_qs = (
#             CollegeTeamMember.objects.annotate(
#                 total_fours=Count('striker_balls', filter=Q(striker_balls__is_four=True))
#             )
#             .filter(total_fours__gt=0)
#             .order_by('-total_fours')[:5]
#         )
#         most_fours = [
#             {"player_id": p.id, "name": p.name, "team": p.college.team_name, "fours": p.total_fours}
#             for p in most_fours_qs
#         ]

#         # I. Sponsors Section
#         sponsors = [
#             {
#                 "id": s.id,
#                 "company_name": s.company_name,
#                 "tier": s.sponsor_tier,
#                 "company_website": s.company_website,
#                 "logo": request.build_absolute_uri(s.company_logo.url) if s.company_logo else None
#             }
#             for s in SponsorRegistration.objects.all().order_by('-created_at')[:10]
#         ]

#         # K. Latest Announcements
#         announcements = [
#             {
#                 "id": a.id,
#                 "title": a.title,
#                 "details": a.details,
#                 "is_pinned": a.is_pinned,
#                 "date": a.created_at.strftime("%d %b %Y")
#             }
#             for a in Announcement.objects.filter(is_active=True).order_by('-is_pinned', '-created_at')[:5]
#         ]

#         return Response({
#             "status": True,
#             "tournament_info": {
#                 "id": active_tournament.id if active_tournament else None,
#                 "name": active_tournament.name if active_tournament else "CSPL Tournament",
#                 "season": active_tournament.season if active_tournament else "Season 2026"
#             },
#             "hero_banners": banners,
#             "live_matches": live_matches_data,
#             "upcoming_matches": upcoming,
#             "recent_results": recent_results,
#             "tournament_snapshot": snapshot,
#             "featured_players": {
#                 "orange_cap": orange_cap,
#                 "purple_cap": purple_cap,
#                 "most_sixes": most_sixes,
#                 "most_fours": most_fours
#             },
#             "sponsors": sponsors,
#             "announcements": announcements
#         }, status=status.HTTP_200_OK)

from decimal import Decimal
from django.utils import timezone
from django.db.models import Sum, Count, Q
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status, permissions

from .models import (
    Tournament, Match, Innings, CollegeRegistration, CollegeTeamMember,
    PointsTable, HomepageBanner, SponsorRegistration, Announcement,
    VideoHighlight, NewsArticle, GalleryMedia, TournamentFAQ
)


class HomepageMasterAPIView(APIView):
    """
    SOW Module 2 & Figma UI 100% Compliant Master Homepage Data Feed.
    Includes:
      - Hero Banners
      - Live Match Center (Poster Thumbnail, YouTube Stream, CRR, RRR, Target, and 12-ball Ticker)
      - Upcoming Fixtures (with Match Poster Thumbnail)
      - Recent Results (with Match Poster Thumbnail)
      - Tournament Snapshot Stats
      - Points Table Standings with NRR
      - Featured Players (Orange/Purple Cap, 6s, 4s)
      - Video Highlights & Match Replays
      - News & Press Articles
      - Photo Gallery Grid
      - Tournament FAQs & Rules
      - Sponsors & Latest Announcements
    """
    permission_classes = [permissions.AllowAny]

    def get(self, request):
        now = timezone.now()
        active_tournament = Tournament.objects.filter(is_active=True).first() or Tournament.objects.last()

        # Helper to safely build absolute URL for images
        def get_media_url(image_field):
            if image_field:
                try:
                    return request.build_absolute_uri(image_field.url)
                except ValueError:
                    return None
            return None

        # A. Hero Banners
        banners = [
            {
                "id": b.id,
                "title": b.title,
                "subtitle": b.subtitle,
                "season_tag": b.season_tag,
                "banner_image": get_media_url(b.banner_image),
                "cta_title": b.cta_title,
                "cta_url": b.cta_url
            }
            for b in HomepageBanner.objects.filter(is_active=True).order_by('-created_at')
        ]

        # B & C & D. Live Matches
        live_matches_data = []
        live_matches = Match.objects.filter(status='live').select_related('team_a', 'team_b', 'venue', 'tournament')
        
        for match in live_matches:
            active_inn = match.innings.filter(is_completed=False).first() or match.innings.last()
            last_ball = active_inn.balls.last() if active_inn else None
            
            # 1. Fetch & Format Last 12 Deliveries History
            recent_balls_formatted = []
            if active_inn:
                recent_balls = active_inn.balls.order_by('-id')[:12]
                for b in reversed(recent_balls):
                    if b.is_wicket:
                        ball_label = "W"
                    elif b.extra_type == 'wide':
                        ball_label = f"{b.extra_runs}Wd" if b.extra_runs > 1 else "Wd"
                    elif b.extra_type == 'no_ball':
                        total_nb = b.runs_scored + b.extra_runs
                        ball_label = f"{total_nb}Nb"
                    elif b.extra_type in ['bye', 'leg_bye']:
                        ball_label = f"{b.extra_runs}B"
                    elif b.runs_scored == 6 or b.is_six:
                        ball_label = "6"
                    elif b.runs_scored == 4 or b.is_four:
                        ball_label = "4"
                    elif b.runs_scored == 0 or b.is_dot_ball:
                        ball_label = "0"
                    else:
                        ball_label = str(b.runs_scored)
                    recent_balls_formatted.append(ball_label)

            # 2. Total Balls Bowled & CRR Calculation
            crr = "0.00"
            target_runs = None
            req_runs = None
            req_balls = None
            rrr = None

            if active_inn:
                overs_float = float(active_inn.total_overs)
                completed_overs = int(overs_float)
                remaining_balls_in_over = int(round((overs_float % 1) * 10))
                total_balls_bowled = (completed_overs * 6) + remaining_balls_in_over

                if total_balls_bowled > 0:
                    crr = f"{(active_inn.total_runs / total_balls_bowled) * 6:.2f}"

                # 3. Target & RRR Calculation (2nd Innings)
                if active_inn.innings_number == 2:
                    inn_1 = match.innings.filter(innings_number=1).first()
                    if inn_1:
                        target_runs = inn_1.total_runs + 1
                        req_runs = max(0, target_runs - active_inn.total_runs)
                        req_balls = max(0, (match.total_overs * 6) - total_balls_bowled)

                        if req_balls > 0:
                            rrr = f"{(req_runs * 6) / req_balls:.2f}"
                        else:
                            rrr = "0.00" if req_runs == 0 else "N/A"

            # 4. YouTube Stream Link
            stream_config = getattr(match, 'live_stream', None)
            youtube_url = stream_config.youtube_stream_url if (stream_config and stream_config.is_live) else None

            live_matches_data.append({
                "match_id": match.id,
                "thumbnail_image": get_media_url(getattr(match, 'thumbnail_image', None)),
                "tournament": match.tournament.name if match.tournament else None,
                "venue": f"{match.venue.name}, {match.venue.city}" if match.venue else None,
                "format": match.format,
                "total_overs": match.total_overs,
                "toss_info": f"{match.toss_winner.team_name} elected to {match.toss_decision}" if match.toss_winner else "Toss pending",
                "team_a": {
                    "id": match.team_a.id,
                    "name": match.team_a.team_name,
                    "college": match.team_a.full_name
                },
                "team_b": {
                    "id": match.team_b.id,
                    "name": match.team_b.team_name,
                    "college": match.team_b.full_name
                },
                "youtube_stream_url": youtube_url,
                "current_score": {
                    "innings_number": active_inn.innings_number if active_inn else 1,
                    "batting_team": active_inn.batting_team.team_name if active_inn else None,
                    "runs": active_inn.total_runs if active_inn else 0,
                    "wickets": active_inn.total_wickets if active_inn else 0,
                    "overs": str(active_inn.total_overs) if active_inn else "0.0",
                    "crr": crr,
                    "target": target_runs,
                    "required_runs": req_runs,
                    "required_balls": req_balls,
                    "rrr": rrr,
                    "recent_balls": recent_balls_formatted
                },
                "quick_panel": {
                    "striker": {
                        "id": last_ball.striker.id,
                        "name": last_ball.striker.name,
                        "code": last_ball.striker.member_code
                    } if (last_ball and last_ball.striker) else None,
                    "non_striker": {
                        "id": last_ball.non_striker.id,
                        "name": last_ball.non_striker.name,
                        "code": last_ball.non_striker.member_code
                    } if (last_ball and last_ball.non_striker) else None,
                    "bowler": {
                        "id": last_ball.bowler.id,
                        "name": last_ball.bowler.name,
                        "code": last_ball.bowler.member_code
                    } if (last_ball and last_ball.bowler) else None
                }
            })

        # E. Upcoming Matches (with thumbnail_image)
        upcoming = [
            {
                "match_id": m.id,
                "thumbnail_image": get_media_url(getattr(m, 'thumbnail_image', None)),
                "teams": f"{m.team_a.team_name} vs {m.team_b.team_name}",
                "team_a": {"id": m.team_a.id, "name": m.team_a.team_name},
                "team_b": {"id": m.team_b.id, "name": m.team_b.team_name},
                "date_time": m.match_datetime.strftime("%Y-%m-%d %H:%M"),
                "venue": f"{m.venue.name}, {m.venue.city}" if m.venue else "TBD",
                "format": m.format
            }
            for m in Match.objects.filter(status='upcoming', match_datetime__gte=now).order_by('match_datetime')[:5]
        ]

        # F. Recent Results (with thumbnail_image)
        recent_results = [
            {
                "match_id": m.id,
                "thumbnail_image": get_media_url(getattr(m, 'thumbnail_image', None)),
                "teams": f"{m.team_a.team_name} vs {m.team_b.team_name}",
                "team_a": {"id": m.team_a.id, "name": m.team_a.team_name},
                "team_b": {"id": m.team_b.id, "name": m.team_b.team_name},
                "winner": m.winner.team_name if m.winner else "No Result / Tie",
                "result_description": m.result_description or "Match Completed",
                "player_of_the_match": m.player_of_match.name if m.player_of_match else None
            }
            for m in Match.objects.filter(status='completed').order_by('-match_datetime')[:5]
        ]

        # G. Tournament Snapshot Cards
        total_matches = Match.objects.filter(tournament=active_tournament).count() if active_tournament else 0
        completed_matches = Match.objects.filter(tournament=active_tournament, status='completed').count() if active_tournament else 0
        live_count = Match.objects.filter(tournament=active_tournament, status='live').count() if active_tournament else 0

        snapshot = {
            "total_teams": CollegeRegistration.objects.filter(status='approved').count(),
            "total_matches": total_matches,
            "completed_matches": completed_matches,
            "live_matches": live_count,
            "upcoming_matches": max(0, total_matches - (completed_matches + live_count)),
            "total_players": CollegeTeamMember.objects.count()
        }

        # G2. Points Table & NRR Standings
        points_table_data = []
        if active_tournament:
            standings = PointsTable.objects.filter(tournament=active_tournament).select_related('team').order_by('-points', '-net_run_rate')
            points_table_data = [
                {
                    "rank": idx + 1,
                    "team_id": entry.team.id,
                    "team_name": entry.team.team_name,
                    "college_name": entry.team.full_name,
                    "matches_played": entry.matches_played,
                    "won": entry.won,
                    "lost": entry.lost,
                    "tied": entry.tied,
                    "no_result": entry.no_result,
                    "points": entry.points,
                    "net_run_rate": f"{entry.net_run_rate:+.3f}"
                }
                for idx, entry in enumerate(standings)
            ]

        # H. Featured Players (Leaderboards)
        top_batsmen_qs = (
            CollegeTeamMember.objects.annotate(total_runs=Sum('striker_balls__runs_scored'))
            .filter(total_runs__isnull=False)
            .order_by('-total_runs')[:5]
        )
        orange_cap = [
            {
                "player_id": p.id,
                "name": p.name,
                "member_code": p.member_code,
                "team": p.college.team_name,
                "runs": p.total_runs
            }
            for p in top_batsmen_qs
        ]

        top_bowlers_qs = (
            CollegeTeamMember.objects.annotate(
                total_wickets=Count('bowled_balls', filter=Q(bowled_balls__is_wicket=True) & ~Q(bowled_balls__wicket_type='run_out'))
            )
            .filter(total_wickets__gt=0)
            .order_by('-total_wickets')[:5]
        )
        purple_cap = [
            {
                "player_id": p.id,
                "name": p.name,
                "member_code": p.member_code,
                "team": p.college.team_name,
                "wickets": p.total_wickets
            }
            for p in top_bowlers_qs
        ]

        most_sixes_qs = (
            CollegeTeamMember.objects.annotate(
                total_sixes=Count('striker_balls', filter=Q(striker_balls__is_six=True))
            )
            .filter(total_sixes__gt=0)
            .order_by('-total_sixes')[:5]
        )
        most_sixes = [
            {"player_id": p.id, "name": p.name, "team": p.college.team_name, "sixes": p.total_sixes}
            for p in most_sixes_qs
        ]

        most_fours_qs = (
            CollegeTeamMember.objects.annotate(
                total_fours=Count('striker_balls', filter=Q(striker_balls__is_four=True))
            )
            .filter(total_fours__gt=0)
            .order_by('-total_fours')[:5]
        )
        most_fours = [
            {"player_id": p.id, "name": p.name, "team": p.college.team_name, "fours": p.total_fours}
            for p in most_fours_qs
        ]

        # I. Video Highlights & Replays (Safe Attribute Lookup)
        video_highlights = []
        for v in VideoHighlight.objects.all()[:6]:
            thumb_field = getattr(v, 'thumbnail', None) or \
                          getattr(v, 'thumbnail_image', None) or \
                          getattr(v, 'video_thumbnail', None) or \
                          getattr(v, 'image', None)

            video_highlights.append({
                "id": v.id,
                "title": v.title,
                "duration": getattr(v, 'duration', "03:30"),
                "thumbnail": get_media_url(thumb_field),
                "youtube_url": getattr(v, 'youtube_url', None) or getattr(v, 'video_url', None),
                "is_featured": getattr(v, 'is_featured', False)
            })

        # J. News & Press Articles
        news_articles = []
        for n in NewsArticle.objects.all()[:5]:
            cover_field = getattr(n, 'cover_image', None) or getattr(n, 'image', None)
            cat_display = n.get_category_display() if hasattr(n, 'get_category_display') else getattr(n, 'category', 'News')

            news_articles.append({
                "id": n.id,
                "title": n.title,
                "category": cat_display,
                "summary": getattr(n, 'summary', ''),
                "cover_image": get_media_url(cover_field),
                "date": n.created_at.strftime("%d %b %Y"),
                "is_featured": getattr(n, 'is_featured', False)
            })

        # K. Photo Gallery / Moments Grid
        gallery_media = [
            {
                "id": g.id,
                "title": g.title,
                "image": get_media_url(getattr(g, 'image', None))
            }
            for g in GalleryMedia.objects.all()[:8]
        ]

        # L. Tournament FAQs & Guidelines
        tournament_faqs = [
            {
                "id": f.id,
                "question": f.question,
                "answer": f.answer
            }
            for f in TournamentFAQ.objects.filter(is_active=True)[:6]
        ]

        # M. Sponsors Section
        sponsors = [
            {
                "id": s.id,
                "company_name": s.company_name,
                "tier": s.sponsor_tier,
                "company_website": s.company_website,
                "logo": get_media_url(s.company_logo)
            }
            for s in SponsorRegistration.objects.all().order_by('-created_at')[:10]
        ]

        # N. Latest Announcements
        announcements = [
            {
                "id": a.id,
                "title": a.title,
                "details": a.details,
                "is_pinned": a.is_pinned,
                "date": a.created_at.strftime("%d %b %Y")
            }
            for a in Announcement.objects.filter(is_active=True).order_by('-is_pinned', '-created_at')[:5]
        ]

        return Response({
            "status": True,
            "tournament_info": {
                "id": active_tournament.id if active_tournament else None,
                "name": active_tournament.name if active_tournament else "CSPL Tournament",
                "season": active_tournament.season if active_tournament else "Season 2026"
            },
            "hero_banners": banners,
            "live_matches": live_matches_data,
            "upcoming_matches": upcoming,
            "recent_results": recent_results,
            "tournament_snapshot": snapshot,
            "points_table": points_table_data,
            "featured_players": {
                "orange_cap": orange_cap,
                "purple_cap": purple_cap,
                "most_sixes": most_sixes,
                "most_fours": most_fours
            },
            "video_highlights": video_highlights,
            "news_articles": news_articles,
            "photo_gallery": gallery_media,
            "tournament_faqs": tournament_faqs,
            "sponsors": sponsors,
            "announcements": announcements
        }, status=status.HTTP_200_OK)
      
# class HomepageMasterAPIView(APIView):
#     """
#     SOW Module 2 Compliant Master Homepage Data Feed.
#     Includes: Hero Banners, Live Matches + Stream, Recent 12 Deliveries Ticker,
#     Upcoming, Recent Results, Tournament Snapshot, Points Table with NRR, 
#     Featured Players, Sponsors & Announcements.
#     """
#     permission_classes = [permissions.AllowAny]

#     def get(self, request):
#         now = timezone.now()
#         active_tournament = Tournament.objects.filter(is_active=True).first() or Tournament.objects.last()

#         # A. Hero Banners
#         banners = [
#             {
#                 "id": b.id,
#                 "title": b.title,
#                 "subtitle": b.subtitle,
#                 "season_tag": b.season_tag,
#                 "banner_image": request.build_absolute_uri(b.banner_image.url) if b.banner_image else None,
#                 "cta_title": b.cta_title,
#                 "cta_url": b.cta_url
#             }
#             for b in HomepageBanner.objects.filter(is_active=True).order_by('-created_at')
#         ]

#         # B & C & D. Live Matches with YouTube Stream, Quick Info Panel & Recent 12 Deliveries
#         live_matches_data = []
#         live_matches = Match.objects.filter(status='live').select_related('team_a', 'team_b', 'venue', 'tournament')
        
#         for match in live_matches:
#             active_inn = match.innings.filter(is_completed=False).first() or match.innings.last()
#             last_ball = active_inn.balls.last() if active_inn else None
            
#             # 1. Fetch & Format Last 12 Deliveries History
#             recent_balls_formatted = []
#             if active_inn:
#                 recent_balls = active_inn.balls.order_by('-id')[:12]
#                 for b in reversed(recent_balls):
#                     if b.is_wicket:
#                         ball_label = "W"
#                     elif b.extra_type == 'wide':
#                         ball_label = f"{b.extra_runs}Wd" if b.extra_runs > 1 else "Wd"
#                     elif b.extra_type == 'no_ball':
#                         total_nb = b.runs_scored + b.extra_runs
#                         ball_label = f"{total_nb}Nb"
#                     elif b.extra_type in ['bye', 'leg_bye']:
#                         ball_label = f"{b.extra_runs}B"
#                     elif b.runs_scored == 6 or b.is_six:
#                         ball_label = "6"
#                     elif b.runs_scored == 4 or b.is_four:
#                         ball_label = "4"
#                     elif b.runs_scored == 0 or b.is_dot_ball:
#                         ball_label = "0"
#                     else:
#                         ball_label = str(b.runs_scored)
#                     recent_balls_formatted.append(ball_label)

#             # 2. YouTube Stream from LiveStreamConfig model
#             stream_config = getattr(match, 'live_stream', None)
#             youtube_url = stream_config.youtube_stream_url if (stream_config and stream_config.is_live) else None

#             # 3. Required runs and balls calculation
#             req_runs = None
#             req_balls = None
#             if active_inn and getattr(active_inn, 'target_runs', None):
#                 req_runs = max(0, active_inn.target_runs - active_inn.total_runs)
#                 current_balls = int(active_inn.total_overs) * 6 + int(round((active_inn.total_overs % 1) * 10))
#                 req_balls = max(0, (match.total_overs * 6) - current_balls)

#             live_matches_data.append({
#                 "match_id": match.id,
#                 "tournament": match.tournament.name if match.tournament else None,
#                 "venue": f"{match.venue.name}, {match.venue.city}" if match.venue else None,
#                 "format": match.format,
#                 "total_overs": match.total_overs,
#                 "toss_info": f"{match.toss_winner.team_name} elected to {match.toss_decision}" if match.toss_winner else "Toss pending",
#                 "team_a": {
#                     "id": match.team_a.id,
#                     "name": match.team_a.team_name,
#                     "college": match.team_a.full_name
#                 },
#                 "team_b": {
#                     "id": match.team_b.id,
#                     "name": match.team_b.team_name,
#                     "college": match.team_b.full_name
#                 },
#                 "youtube_stream_url": youtube_url,
#                 "current_score": {
#                     "innings_number": active_inn.innings_number if active_inn else 1,
#                     "batting_team": active_inn.batting_team.team_name if active_inn else None,
#                     "runs": active_inn.total_runs if active_inn else 0,
#                     "wickets": active_inn.total_wickets if active_inn else 0,
#                     "overs": str(active_inn.total_overs) if active_inn else "0.0",
#                     "required_runs": req_runs,
#                     "required_balls": req_balls,
#                     "recent_balls": recent_balls_formatted  # <-- Last 12 Deliveries list
#                 },
#                 "quick_panel": {
#                     "striker": {
#                         "id": last_ball.striker.id,
#                         "name": last_ball.striker.name,
#                         "code": last_ball.striker.member_code
#                     } if (last_ball and last_ball.striker) else None,
#                     "non_striker": {
#                         "id": last_ball.non_striker.id,
#                         "name": last_ball.non_striker.name,
#                         "code": last_ball.non_striker.member_code
#                     } if (last_ball and last_ball.non_striker) else None,
#                     "bowler": {
#                         "id": last_ball.bowler.id,
#                         "name": last_ball.bowler.name,
#                         "code": last_ball.bowler.member_code
#                     } if (last_ball and last_ball.bowler) else None
#                 }
#             })

#         # E. Upcoming Matches
#         upcoming = [
#             {
#                 "match_id": m.id,
#                 "teams": f"{m.team_a.team_name} vs {m.team_b.team_name}",
#                 "date_time": m.match_datetime.strftime("%Y-%m-%d %H:%M"),
#                 "venue": f"{m.venue.name}, {m.venue.city}" if m.venue else "TBD",
#                 "format": m.format
#             }
#             for m in Match.objects.filter(status='upcoming', match_datetime__gte=now).order_by('match_datetime')[:5]
#         ]

#         # F. Recent Results
#         recent_results = [
#             {
#                 "match_id": m.id,
#                 "teams": f"{m.team_a.team_name} vs {m.team_b.team_name}",
#                 "winner": m.winner.team_name if m.winner else "No Result / Tie",
#                 "result_description": m.result_description or "Match Completed",
#                 "player_of_the_match": m.player_of_match.name if m.player_of_match else None
#             }
#             for m in Match.objects.filter(status='completed').order_by('-match_datetime')[:5]
#         ]

#         # G. Tournament Snapshot Cards
#         total_matches = Match.objects.filter(tournament=active_tournament).count() if active_tournament else 0
#         completed_matches = Match.objects.filter(tournament=active_tournament, status='completed').count() if active_tournament else 0
#         live_count = Match.objects.filter(tournament=active_tournament, status='live').count() if active_tournament else 0

#         snapshot = {
#             "total_teams": CollegeRegistration.objects.filter(status='approved').count(),
#             "total_matches": total_matches,
#             "completed_matches": completed_matches,
#             "live_matches": live_count,
#             "upcoming_matches": max(0, total_matches - (completed_matches + live_count)),
#             "total_players": CollegeTeamMember.objects.count()
#         }

#         # G2. Points Table & NRR Standings
#         points_table_data = []
#         if active_tournament:
#             standings = PointsTable.objects.filter(tournament=active_tournament).select_related('team').order_by('-points', '-net_run_rate')
#             points_table_data = [
#                 {
#                     "rank": idx + 1,
#                     "team_id": entry.team.id,
#                     "team_name": entry.team.team_name,
#                     "college_name": entry.team.full_name,
#                     "matches_played": entry.matches_played,
#                     "won": entry.won,
#                     "lost": entry.lost,
#                     "tied": entry.tied,
#                     "no_result": entry.no_result,
#                     "points": entry.points,
#                     "net_run_rate": f"{entry.net_run_rate:+.3f}"
#                 }
#                 for idx, entry in enumerate(standings)
#             ]

#         # H. Featured Players (Aggregated from BallByBall deliveries)
#         top_batsmen_qs = (
#             CollegeTeamMember.objects.annotate(total_runs=Sum('striker_balls__runs_scored'))
#             .filter(total_runs__isnull=False)
#             .order_by('-total_runs')[:5]
#         )
#         orange_cap = [
#             {
#                 "player_id": p.id,
#                 "name": p.name,
#                 "member_code": p.member_code,
#                 "team": p.college.team_name,
#                 "runs": p.total_runs
#             }
#             for p in top_batsmen_qs
#         ]

#         top_bowlers_qs = (
#             CollegeTeamMember.objects.annotate(
#                 total_wickets=Count('bowled_balls', filter=Q(bowled_balls__is_wicket=True) & ~Q(bowled_balls__wicket_type='run_out'))
#             )
#             .filter(total_wickets__gt=0)
#             .order_by('-total_wickets')[:5]
#         )
#         purple_cap = [
#             {
#                 "player_id": p.id,
#                 "name": p.name,
#                 "member_code": p.member_code,
#                 "team": p.college.team_name,
#                 "wickets": p.total_wickets
#             }
#             for p in top_bowlers_qs
#         ]

#         most_sixes_qs = (
#             CollegeTeamMember.objects.annotate(
#                 total_sixes=Count('striker_balls', filter=Q(striker_balls__is_six=True))
#             )
#             .filter(total_sixes__gt=0)
#             .order_by('-total_sixes')[:5]
#         )
#         most_sixes = [
#             {"player_id": p.id, "name": p.name, "team": p.college.team_name, "sixes": p.total_sixes}
#             for p in most_sixes_qs
#         ]

#         most_fours_qs = (
#             CollegeTeamMember.objects.annotate(
#                 total_fours=Count('striker_balls', filter=Q(striker_balls__is_four=True))
#             )
#             .filter(total_fours__gt=0)
#             .order_by('-total_fours')[:5]
#         )
#         most_fours = [
#             {"player_id": p.id, "name": p.name, "team": p.college.team_name, "fours": p.total_fours}
#             for p in most_fours_qs
#         ]

#         # I. Sponsors Section
#         sponsors = [
#             {
#                 "id": s.id,
#                 "company_name": s.company_name,
#                 "tier": s.sponsor_tier,
#                 "company_website": s.company_website,
#                 "logo": request.build_absolute_uri(s.company_logo.url) if s.company_logo else None
#             }
#             for s in SponsorRegistration.objects.all().order_by('-created_at')[:10]
#         ]

#         # K. Latest Announcements
#         announcements = [
#             {
#                 "id": a.id,
#                 "title": a.title,
#                 "details": a.details,
#                 "is_pinned": a.is_pinned,
#                 "date": a.created_at.strftime("%d %b %Y")
#             }
#             for a in Announcement.objects.filter(is_active=True).order_by('-is_pinned', '-created_at')[:5]
#         ]

#         return Response({
#             "status": True,
#             "tournament_info": {
#                 "id": active_tournament.id if active_tournament else None,
#                 "name": active_tournament.name if active_tournament else "CSPL Tournament",
#                 "season": active_tournament.season if active_tournament else "Season 2026"
#             },
#             "hero_banners": banners,
#             "live_matches": live_matches_data,
#             "upcoming_matches": upcoming,
#             "recent_results": recent_results,
#             "tournament_snapshot": snapshot,
#             "points_table": points_table_data,
#             "featured_players": {
#                 "orange_cap": orange_cap,
#                 "purple_cap": purple_cap,
#                 "most_sixes": most_sixes,
#                 "most_fours": most_fours
#             },
#             "sponsors": sponsors,
#             "announcements": announcements
#         }, status=status.HTTP_200_OK)


        
from decimal import Decimal
from django.db.models import Sum, Count, Q


class FullMatchScorecardAPIView(APIView):
    permission_classes = [permissions.AllowAny]

    def get(self, request, match_id):
        match = Match.objects.filter(id=match_id).first()
        if not match:
            return Response({"status": False, "message": "Match not found."}, status=status.HTTP_404_NOT_FOUND)

        innings_list = []
        for inn in match.innings.all().order_by('innings_number'):
            # --- Batting Card ---
            batters_data = []
            # Jo players batting kar chuke hain ya out ho chuke hain
            batsmen_ids = inn.balls.values_list('striker', flat=True).distinct()
            
            for p_id in batsmen_ids:
                player_balls = inn.balls.filter(striker_id=p_id)
                runs = player_balls.aggregate(r=Sum('runs_scored'))['r'] or 0
                balls_faced = player_balls.filter(extra_type__in=['none', 'bye', 'leg_bye']).count()
                fours = player_balls.filter(is_four=True).count()
                sixes = player_balls.filter(is_six=True).count()
                strike_rate = round((runs / balls_faced * 100), 2) if balls_faced > 0 else 0.0

                # Dismissal status
                dismissal = inn.balls.filter(player_dismissed_id=p_id, is_wicket=True).first()
                dismissal_text = "not out"
                if dismissal:
                    if dismissal.wicket_type == 'bowled':
                        dismissal_text = f"b {dismissal.bowler.name}"
                    elif dismissal.wicket_type == 'caught':
                        fielder_name = dismissal.fielder_involved.name if dismissal.fielder_involved else "sub"
                        dismissal_text = f"c {fielder_name} b {dismissal.bowler.name}"
                    elif dismissal.wicket_type == 'run_out':
                        fielder_name = dismissal.fielder_involved.name if dismissal.fielder_involved else "fielder"
                        dismissal_text = f"run out ({fielder_name})"
                    elif dismissal.wicket_type == 'lbw':
                        dismissal_text = f"lbw b {dismissal.bowler.name}"
                    elif dismissal.wicket_type == 'stumped':
                        keeper_name = dismissal.fielder_involved.name if dismissal.fielder_involved else "wk"
                        dismissal_text = f"st {keeper_name} b {dismissal.bowler.name}"
                    else:
                        dismissal_text = dismissal.wicket_type.replace('_', ' ').title()

                batter_obj = CollegeTeamMember.objects.filter(id=p_id).first()
                batters_data.append({
                    "player_id": p_id,
                    "player_name": batter_obj.name if batter_obj else "Unknown",
                    "runs": runs,
                    "balls": balls_faced,
                    "fours": fours,
                    "sixes": sixes,
                    "strike_rate": strike_rate,
                    "dismissal": dismissal_text
                })

            # --- Bowling Card ---
            bowlers_data = []
            bowler_ids = inn.balls.values_list('bowler', flat=True).distinct()

            for b_id in bowler_ids:
                b_deliveries = inn.balls.filter(bowler_id=b_id)
                legal_balls = b_deliveries.filter(extra_type__in=['none', 'bye', 'leg_bye', 'penalty']).count()
                overs_bowled = f"{legal_balls // 6}.{legal_balls % 6}"
                runs_conceded = b_deliveries.exclude(extra_type__in=['bye', 'leg_bye']).aggregate(
                    r=Sum('runs_scored') + Sum('extra_runs')
                )['r'] or 0
                wickets = b_deliveries.filter(is_wicket=True).exclude(
                    wicket_type__in=['run_out', 'retired_hurt', 'retired_out']
                ).count()

                # Economy calculation
                ov_float = (legal_balls // 6) + ((legal_balls % 6) / 6.0)
                economy = round((runs_conceded / ov_float), 2) if ov_float > 0 else 0.0

                bowler_obj = CollegeTeamMember.objects.filter(id=b_id).first()
                bowlers_data.append({
                    "bowler_id": b_id,
                    "bowler_name": bowler_obj.name if bowler_obj else "Unknown",
                    "overs": overs_bowled,
                    "runs_conceded": runs_conceded,
                    "wickets": wickets,
                    "economy": economy,
                })

            # --- Fall of Wickets (FOW) ---
            fow_deliveries = inn.balls.filter(is_wicket=True).order_by('id')
            fow_data = []
            w_count = 1
            running_runs = 0
            for b in inn.balls.order_by('id'):
                running_runs += (b.runs_scored + b.extra_runs)
                if b.is_wicket:
                    fow_data.append({
                        "wicket_num": w_count,
                        "score": running_runs,
                        "overs": f"{b.over_number}.{b.ball_number}",
                        "player_out": b.player_dismissed.name if b.player_dismissed else "Unknown"
                    })
                    w_count += 1

            # --- Extras Breakdown ---
            extras_agg = inn.balls.aggregate(
                wides=Sum('extra_runs', filter=Q(extra_type='wide')),
                no_balls=Sum('extra_runs', filter=Q(extra_type='no_ball')),
                byes=Sum('extra_runs', filter=Q(extra_type='bye')),
                leg_byes=Sum('extra_runs', filter=Q(extra_type='leg_bye')),
                penalties=Sum('extra_runs', filter=Q(extra_type='penalty')),
                total_extras=Sum('extra_runs')
            )

            innings_list.append({
                "innings_number": inn.innings_number,
                "batting_team": inn.batting_team.team_name,
                "bowling_team": inn.bowling_team.team_name,
                "total_runs": inn.total_runs,
                "total_wickets": inn.total_wickets,
                "total_overs": str(inn.total_overs),
                "extras": {
                    "wides": extras_agg['wides'] or 0,
                    "no_balls": extras_agg['no_balls'] or 0,
                    "byes": extras_agg['byes'] or 0,
                    "leg_byes": extras_agg['leg_byes'] or 0,
                    "total": extras_agg['total_extras'] or 0
                },
                "batting_card": batters_data,
                "bowling_card": bowlers_data,
                "fall_of_wickets": fow_data
            })

        return Response({
            "status": True,
            "match_details": {
                "id": match.id,
                "tournament": match.tournament.name,
                "format": match.format,
                "status": match.status,
                "result": match.result_description,
                "toss": f"{match.toss_winner.team_name} chose to {match.toss_decision}" if match.toss_winner else None,
                "venue": str(match.venue) if match.venue else None
            },
            "innings": innings_list
        }, status=status.HTTP_200_OK)



class UndoBallAPIView(APIView):
    permission_classes = [permissions.AllowAny]

    def post(self, request, innings_id):
        innings = Innings.objects.filter(id=innings_id).first()
        if not innings:
            return Response({"status": False, "message": "Innings not found."}, status=status.HTTP_404_NOT_FOUND)

        updated_inn, msg = ScoringEngineService.undo_last_delivery(innings)
        if not updated_inn:
            return Response({"status": False, "message": msg}, status=status.HTTP_400_BAD_REQUEST)

        return Response({
            "status": True,
            "message": msg,
            "innings_total_runs": updated_inn.total_runs,
            "innings_total_wickets": updated_inn.total_wickets,
            "innings_total_overs": str(updated_inn.total_overs)
        }, status=status.HTTP_200_OK)



from decimal import Decimal
from django.db.models import Sum, Count, Q, Max


class PlayerProfileStatsAPIView(APIView):
    permission_classes = [permissions.AllowAny]

    def get(self, request, player_id):
        player = CollegeTeamMember.objects.filter(id=player_id).first()
        if not player:
            return Response({"status": False, "message": "Player not found."}, status=status.HTTP_404_NOT_FOUND)

        # 1. Total Matches Played
        matches_played = MatchPlayingXI.objects.filter(
            player=player,
            match__status='completed'
        ).values('match').distinct().count()

        # 2. Batting Statistics
        batting_deliveries = BallByBall.objects.filter(striker=player)
        total_runs = batting_deliveries.aggregate(r=Sum('runs_scored'))['r'] or 0
        balls_faced = batting_deliveries.filter(extra_type__in=['none', 'bye', 'leg_bye']).count()
        total_fours = batting_deliveries.filter(is_four=True).count()
        total_sixes = batting_deliveries.filter(is_six=True).count()

        # Times Dismissed & Batting Average
        times_out = BallByBall.objects.filter(player_dismissed=player, is_wicket=True).count()
        batting_avg = round((total_runs / times_out), 2) if times_out > 0 else float(total_runs)
        strike_rate = round((total_runs / balls_faced * 100), 2) if balls_faced > 0 else 0.0

        # Highest Score in an Innings
        innings_scores = batting_deliveries.values('innings').annotate(inn_runs=Sum('runs_scored')).order_by('-inn_runs')
        highest_score = innings_scores[0]['inn_runs'] if innings_scores.exists() else 0

        # 3. Bowling Statistics
        bowling_deliveries = BallByBall.objects.filter(bowler=player)
        legal_bowled = bowling_deliveries.filter(extra_type__in=['none', 'bye', 'leg_bye', 'penalty']).count()
        overs_bowled = f"{legal_bowled // 6}.{legal_bowled % 6}"
        
        runs_conceded = bowling_deliveries.exclude(extra_type__in=['bye', 'leg_bye']).aggregate(
            r=Sum('runs_scored') + Sum('extra_runs')
        )['r'] or 0
        
        total_wickets = bowling_deliveries.filter(is_wicket=True).exclude(
            wicket_type__in=['run_out', 'retired_hurt', 'retired_out']
        ).count()

        ov_float = (legal_bowled // 6) + ((legal_bowled % 6) / 6.0)
        bowling_economy = round((runs_conceded / ov_float), 2) if ov_float > 0 else 0.0

        # 4. Fielding Statistics
        catches = BallByBall.objects.filter(fielder_involved=player, is_wicket=True, wicket_type='caught').count()
        run_outs = BallByBall.objects.filter(fielder_involved=player, is_wicket=True, wicket_type='run_out').count()
        stumpings = BallByBall.objects.filter(fielder_involved=player, is_wicket=True, wicket_type='stumped').count()

        return Response({
            "status": True,
            "player_info": {
                "id": player.id,
                "name": player.name,
                "member_code": player.member_code,
                "team": player.college.team_name if player.college else None,
                "role": player.role,
                "photo": player.photo.url if player.photo else None
            },
            "career_stats": {
                "matches": matches_played,
                "batting": {
                    "runs": total_runs,
                    "balls_faced": balls_faced,
                    "highest_score": highest_score,
                    "average": batting_avg,
                    "strike_rate": strike_rate,
                    "fours": total_fours,
                    "sixes": total_sixes,
                    "dismissals": times_out
                },
                "bowling": {
                    "overs": overs_bowled,
                    "runs_conceded": runs_conceded,
                    "wickets": total_wickets,
                    "economy": bowling_economy
                },
                "fielding": {
                    "catches": catches,
                    "run_outs": run_outs,
                    "stumpings": stumpings
                }
            }
        }, status=status.HTTP_200_OK)


class MatchAnalyticsAPIView(APIView):
    permission_classes = [permissions.AllowAny]

    def get(self, request, match_id):
        match = Match.objects.filter(id=match_id).first()
        if not match:
            return Response({"status": False, "message": "Match not found."}, status=status.HTTP_404_NOT_FOUND)

        analytics_data = []

        for inn in match.innings.all().order_by('innings_number'):
            # Fetch all balls ordered by time
            balls = inn.balls.all().order_by('over_number', 'ball_number')
            
            # Group deliveries by over
            overs_map = {}
            running_score = 0

            for b in balls:
                ov = b.over_number + 1  # 1-indexed over number for UI
                if ov not in overs_map:
                    overs_map[ov] = {
                        "over": ov,
                        "runs_in_over": 0,
                        "wickets_in_over": 0,
                        "is_maiden": False
                    }
                
                total_ball_runs = b.runs_scored + b.extra_runs
                overs_map[ov]["runs_in_over"] += total_ball_runs
                if b.is_wicket and b.wicket_type != 'retired_hurt':
                    overs_map[ov]["wickets_in_over"] += 1

            # Build Manhattan and Worm Graph arrays
            manhattan = []
            worm_graph = []

            for ov_num in sorted(overs_map.keys()):
                info = overs_map[ov_num]
                running_score += info["runs_in_over"]
                info["is_maiden"] = (info["runs_in_over"] == 0)
                
                manhattan.append(info)
                worm_graph.append({
                    "over": ov_num,
                    "cumulative_runs": running_score,
                    "wickets_fallen": inn.balls.filter(
                        over_number__lt=ov_num, 
                        is_wicket=True
                    ).exclude(wicket_type='retired_hurt').count()
                })

            # Run rate progression
            total_overs_dec = float(inn.total_overs)
            crr = round((inn.total_runs / total_overs_dec), 2) if total_overs_dec > 0 else 0.0

            analytics_data.append({
                "innings_number": inn.innings_number,
                "team": inn.batting_team.team_name,
                "total_runs": inn.total_runs,
                "total_wickets": inn.total_wickets,
                "current_run_rate": crr,
                "manhattan_chart": manhattan,
                "worm_graph": worm_graph
            })

        return Response({
            "status": True,
            "match_id": match.id,
            "analytics": analytics_data
        }, status=status.HTTP_200_OK)


class ScorerMatchContextAPIView(APIView):
    """
    Returns active innings data and playing XI of both teams for the scorer frontend.
    """
    permission_classes = [permissions.AllowAny]

    def get(self, request, match_id):
        match = Match.objects.filter(id=match_id).first()
        if not match:
            return Response({
                "status": False,
                "message": "Match not found."
            }, status=status.HTTP_404_NOT_FOUND)

        active_innings = match.innings.filter(is_completed=False).first()
        if not active_innings:
            active_innings = match.innings.order_by('innings_number').first()

        def serialize_xi(team):
            if not team:
                return []
            return [
                {
                    "player_id": xi.player.id,
                    "name": xi.player.name,
                    "role": xi.player.role,
                    "is_captain": xi.is_captain,
                    "is_wicketkeeper": xi.is_wicketkeeper
                }
                for xi in MatchPlayingXI.objects.filter(match=match, team=team).select_related('player')
            ]

        # Get active batsman & bowler from latest ball if available
        last_ball = active_innings.balls.last() if active_innings else None

        return Response({
            "status": True,
            "match_meta": {
                "match_id": match.id,
                "tournament": match.tournament.name if match.tournament else None,
                "status": match.status,
                "total_overs": match.total_overs,
                "team_a": {
                    "id": match.team_a.id,
                    "name": match.team_a.team_name
                } if match.team_a else None,
                "team_b": {
                    "id": match.team_b.id,
                    "name": match.team_b.team_name
                } if match.team_b else None,
            },
            "active_innings": {
                "innings_id": active_innings.id if active_innings else None,
                "innings_number": active_innings.innings_number if active_innings else 1,
                "batting_team_id": active_innings.batting_team_id if active_innings else None,
                "bowling_team_id": active_innings.bowling_team_id if active_innings else None,
                "total_runs": active_innings.total_runs if active_innings else 0,
                "total_wickets": active_innings.total_wickets if active_innings else 0,
                "total_overs": str(active_innings.total_overs) if active_innings else "0.0"
            },
            "current_positions": {
                "striker_id": last_ball.striker_id if last_ball else None,
                "non_striker_id": last_ball.non_striker_id if last_ball else None,
                "bowler_id": last_ball.bowler_id if last_ball else None
            },
            "squads": {
                "team_a_players": serialize_xi(match.team_a),
                "team_b_players": serialize_xi(match.team_b)
            }
        }, status=status.HTTP_200_OK)



class NewsletterSubscribeAPIView(APIView):
    """
    Footer Newsletter Subscription Endpoint.
    """
    permission_classes = [permissions.AllowAny]

    def post(self, request):
        email = request.data.get('email', '').strip().lower()
        if not email:
            return Response({"status": False, "message": "Email is required."}, status=status.HTTP_400_BAD_REQUEST)
        
        subscription, created = NewsletterSubscription.objects.get_or_create(email=email)
        if not created:
            return Response({"status": True, "message": "You are already subscribed to CSPL updates!"}, status=status.HTTP_200_OK)

        return Response({"status": True, "message": "Successfully subscribed to CSPL updates!"}, status=status.HTTP_201_CREATED)


