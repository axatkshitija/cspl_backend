from django.contrib import admin
from django.urls import  path, include
from cspl_app.views import CollegeBasicInfoCreateAPIView
from .views import *

urlpatterns = [
    path('admin/', admin.site.urls),
    path('api/college/basic-info/', CollegeBasicInfoCreateAPIView.as_view(), name='college-basic-info-create'),
    path("api/college/login/", SendOTPView.as_view(), name="send-otp"),
    path("api/college/verify-otp/",VerifyOTPView.as_view(), name="verify-otp"),
    path("api/college/institution-information/", InstitutionInformationUpdateAPIView.as_view(), name="institution-information-update"),
    path('api/college/add-team-members/', AddTeamMembersAPIView.as_view(), name='add-team-members'),
    path('api/college/upload-documents/',CollegeDocumentUploadAPIView.as_view(),name='college-upload-documents'),
         
        #  ================================================================
        # Sponsor- registrations
        # ======================================================
    path("api/college/sponsor-registration/",SponsorRegistrationAPIView.as_view(),name="sponsor-registration"),
    
    path('send-contact-otp/', SendCollegeContactOTPAPIView.as_view(), name='send-contact-otp'),
    path('verify-contact-otp/',VerifyCollegeContactOTPAPIView.as_view(), name='verify-contact-otp'),
    path("api/college/master-data/", CollegeMasterDataAPIView.as_view(), name="college-master-data"),
    path(
        "vender-register/",
        VendorRegistrationCreateAPIView.as_view(),
        name="vendor-register",
    ),
    path(
        "vender-send-contact-otp/",
        SendVendorContactOTPAPIView.as_view(),
        name="vendor-send-contact-otp",
    ),
    path(
        "vender-verify-contact-otp/",
        VerifyVendorContactOTPAPIView.as_view(),
        name="vendor-verify-contact-otp",
    ),
    path(
        "vender-list/",
        VendorRegistrationListAPIView.as_view(),
        name="vendor-registration-list",
    ),
    path(
        "vender-detail/<int:pk>/",
        VendorRegistrationDetailAPIView.as_view(),
        name="vendor-registration-detail",
    ),

# ==============================================================================
    # TOURNAMENT & LIVE SCORING API ROUTES
    # ==============================================================================
    path('scoring/match-setup/', MatchSetupAPIView.as_view(), name='scoring-match-setup'),
    path('scoring/match/<int:match_id>/toss/', RecordTossAPI.as_view(), name='scoring-record-toss'),
    path('scoring/match/<int:match_id>/start-innings/', StartInningsAPIView.as_view(), name='scoring-start-innings'),
    path('scoring/innings/<int:innings_id>/record-ball/', RecordBallAPIView.as_view(), name='scoring-record-ball'),
    path('scoring/innings/<int:innings_id>/undo-ball/',UndoBallAPIView.as_view(), name='scoring-undo-ball'),
    
    # Public & Fan Endpoints
    path('matches/<int:match_id>/scorecard/', LiveMatchScorecardAPIView.as_view(), name='match-scorecard'),
    path('tournament/<int:tournament_id>/leaderboard/', TournamentLeaderboardAPIView.as_view(), name='tournament-leaderboard'),
    path('homepage/master/', HomepageMasterAPIView.as_view(), name='homepage-master-data'),   
    path('matches/<int:match_id>/full-scorecard/', FullMatchScorecardAPIView.as_view(), name='full-match-scorecard'),  
    path('players/<int:player_id>/profile/',PlayerProfileStatsAPIView.as_view(), name='player-profile-stats'),
    path('matches/<int:match_id>/analytics/', MatchAnalyticsAPIView.as_view(), name='match-analytics'),
    path('matches/<int:match_id>/scorer-context/', ScorerMatchContextAPIView.as_view(), name='scorer-match-context'),
    path('newsletter/subscribe/', NewsletterSubscribeAPIView.as_view(), name='newsletter-subscribe'),

]